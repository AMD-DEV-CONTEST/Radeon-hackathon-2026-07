from __future__ import annotations

import json
from pathlib import Path


def test_twelve_regression_questions_recall_and_citation_completeness(
    legal_retriever,
):
    questions = json.loads(
        Path("data/laws/regression_questions.json").read_text(encoding="utf-8")
    )
    reciprocal_ranks = []
    complete = 0
    for question in questions:
        citations = legal_retriever.citations(
            question["question"], top_k=4, candidate_k=10
        )
        expected = {
            (item["document_id"], item["article_no"])
            for item in question["expected"]
        }
        ranks = [
            index
            for index, citation in enumerate(citations, start=1)
            if (citation.document_id, citation.article_no) in expected
        ]
        assert ranks, question["id"]
        reciprocal_ranks.append(1 / ranks[0])
        complete += all(
            (
                citation.title,
                citation.version,
                citation.effective_date,
                citation.source_id,
                citation.text_source_url,
                citation.quote_type,
                citation.quote,
            )
            for citation in citations
        )
    assert len(questions) == 12
    assert len(reciprocal_ranks) / len(questions) == 1.0
    assert sum(reciprocal_ranks) / len(questions) >= 0.75
    assert complete / len(questions) == 1.0

"""Deterministic cases used by the local three-agent experience.

The fixtures start after evidence reconstruction. They never pretend to be
real accident materials and do not invoke OCR, video processing, or a model.
"""

from __future__ import annotations

import tempfile
import uuid
from dataclasses import dataclass

from app.evidence.workspace import CaseWorkspace
from app.schemas.evidence import (
    EvidenceConflict,
    EvidenceNode,
    Fact,
    FactStatus,
    SourceRole,
)


@dataclass(frozen=True)
class ExperienceScenario:
    scenario_id: str
    short_label: str
    title: str
    description: str
    expected_effect: str
    roles: tuple[SourceRole, ...]
    fact_rows: tuple[tuple[str, str, str, str], ...]
    conflicts: tuple[tuple[int, ...], ...] = ()

    def public_summary(self) -> dict[str, str]:
        return {
            "scenario_id": self.scenario_id,
            "short_label": self.short_label,
            "title": self.title,
            "description": self.description,
            "expected_effect": self.expected_effect,
        }


SCENARIOS: dict[str, ExperienceScenario] = {
    "demo_a": ExperienceScenario(
        scenario_id="demo_a",
        short_label="A",
        title="材料较完整",
        description="路口碰撞，登记、鉴定、信号相位和车辆参数较完整。",
        expected_effect="可形成受限定的车辆属性判断和责任置信分布。",
        roles=(
            SourceRole.ACCIDENT_DETERMINATION,
            SourceRole.DELIVERY_INFORMATION,
            SourceRole.DASHCAM_VIDEO,
            SourceRole.SCENE_PHOTO,
            SourceRole.ROAD_SIGNAL_EVIDENCE,
            SourceRole.VEHICLE_REGISTRATION,
            SourceRole.VEHICLE_CERTIFICATE_CCC,
            SourceRole.VEHICLE_TECHNICAL_PARAMETERS,
            SourceRole.APPRAISAL_REPORT,
            SourceRole.INQUIRY_RECORD,
            SourceRole.MEDICAL_RECORD,
            SourceRole.INSURANCE_POLICY,
        ),
        fact_rows=(
            ("事故发生时间为2026-07-20 08:30", "事故", "事故时间", "2026-07-20"),
            ("事故认定书送达日期为2026-07-28", "事故认定书", "送达日期", "2026-07-28"),
            (
                "两轮车辆碰撞前沿机动车道逆行进入路口",
                "两轮车辆",
                "行驶方向",
                "逆行进入路口",
            ),
            (
                "信号相位记录显示两轮车辆违反停止信号",
                "两轮车辆",
                "信号灯状态",
                "违反停止信号",
            ),
            (
                "两轮车辆在进入路口前未让优先通行车辆",
                "两轮车辆",
                "让行义务",
                "未让行",
            ),
            (
                "机动车驾驶人在碰撞前疏于观察",
                "机动车驾驶人",
                "观察注意",
                "疏于观察",
            ),
            (
                "机动车采取制动且现场记录有刹车痕迹",
                "机动车驾驶人",
                "制动避让",
                "已制动",
            ),
            (
                "现场勘查图标注碰撞点位于路口机动车道内",
                "事故",
                "碰撞点",
                "机动车道内",
            ),
            (
                "两轮车辆登记类型为电动自行车",
                "两轮车辆",
                "登记类型",
                "电动自行车",
            ),
            (
                "车辆属性鉴定意见为非机动车",
                "两轮车辆",
                "车辆属性鉴定",
                "非机动车",
            ),
            (
                "两轮车辆最高设计车速为25 km/h",
                "两轮车辆",
                "最高设计车速",
                "25 km/h",
            ),
            (
                "两轮车辆整车质量为52 kg，使用锂离子电池",
                "两轮车辆",
                "整车质量",
                "52 kg",
            ),
            (
                "两轮车辆电机额定连续输出功率为400 W",
                "两轮车辆",
                "额定连续输出功率",
                "400 W",
            ),
            (
                "车辆合格证和CCC记录与实车车型一致",
                "两轮车辆",
                "产品合格证/CCC",
                "已核验",
            ),
            (
                "保险单记载已投保交强险及商业险",
                "机动车",
                "保险单",
                "交强险及商业险",
            ),
        ),
    ),
    "demo_b": ExperienceScenario(
        scenario_id="demo_b",
        short_label="B",
        title="车辆属性证据不足",
        description="只有认定书、现场照片和一项明显超标的速度参数。",
        expected_effect="技术超标不会直接定性为机动车，唯一责任结论被阻断。",
        roles=(
            SourceRole.ACCIDENT_DETERMINATION,
            SourceRole.SCENE_PHOTO,
        ),
        fact_rows=(
            ("事故发生时间为2026-07-20", "事故", "事故时间", "2026-07-20"),
            ("机动车与两轮车辆在路口发生碰撞", "事故", "碰撞位置", "路口"),
            (
                "两轮车辆最高设计车速为45 km/h",
                "两轮车辆",
                "最高设计车速",
                "45 km/h",
            ),
        ),
    ),
    "demo_c": ExperienceScenario(
        scenario_id="demo_c",
        short_label="C",
        title="材料相互冲突",
        description="登记类型和驶入方向在认定书、视频与照片之间互相矛盾。",
        expected_effect="车辆属性降置信度并进入 disputed，只保留多责任假设。",
        roles=(
            SourceRole.ACCIDENT_DETERMINATION,
            SourceRole.DASHCAM_VIDEO,
            SourceRole.SCENE_PHOTO,
            SourceRole.VEHICLE_REGISTRATION,
        ),
        fact_rows=(
            ("事故发生时间为2026-07-20", "事故", "事故时间", "2026-07-20"),
            (
                "认定书记载两轮车辆登记为电动自行车",
                "两轮车辆",
                "登记类型",
                "电动自行车",
            ),
            (
                "照片中的登记查询记录显示为普通摩托车",
                "两轮车辆",
                "登记类型",
                "普通摩托车",
            ),
            (
                "视频显示两轮车辆由支路驶入",
                "两轮车辆",
                "驶入方向",
                "由支路驶入",
            ),
            (
                "认定书记载两轮车辆由主路驶入",
                "两轮车辆",
                "驶入方向",
                "由主路驶入",
            ),
        ),
        conflicts=((2, 3), (4, 5)),
    ),
}


def list_experience_scenarios() -> list[dict[str, str]]:
    return [scenario.public_summary() for scenario in SCENARIOS.values()]


def seed_experience_case(
    workspace: CaseWorkspace, scenario_id: str
) -> tuple[str, ExperienceScenario]:
    try:
        scenario = SCENARIOS[scenario_id]
    except KeyError as exc:
        raise KeyError(f"Unknown experience scenario: {scenario_id}") from exc

    suffix = uuid.uuid4().hex[:8].upper()
    case_id = f"CASE-EXP-{scenario.short_label}-{suffix}"
    workspace.create_case(case_id)
    store = workspace.store(case_id)
    node_ids: list[str] = []

    for index, role in enumerate(scenario.roles, start=1):
        fixture_bytes = (
            "%PDF-1.4\n"
            f"% Synthetic experience material: {scenario_id}/{role.value}/{index}\n"
            "%%EOF\n"
        ).encode()
        with tempfile.NamedTemporaryFile(suffix=".pdf") as fixture:
            fixture.write(fixture_bytes)
            fixture.flush()
            source = workspace.ingest_file(
                case_id,
                fixture.name,
                role=role,
                original_name=f"{index:02d}-{role.value}-synthetic.pdf",
            )
        node_id = f"NODE-{case_id}-{index:02d}"
        store.add_node(
            EvidenceNode(
                node_id=node_id,
                case_id=case_id,
                source_id=source.source_id,
                node_type="document_text",
                locator={"page": 1, "synthetic": True},
                content=f"{role.value} 合成体验材料",
                extraction_method="synthetic_experience_fixture",
                metadata={"synthetic": True, "contains_personal_data": False},
            )
        )
        node_ids.append(node_id)

    for index, (statement, subject, predicate, value) in enumerate(
        scenario.fact_rows, start=1
    ):
        store.add_fact(
            Fact(
                fact_id=f"FACT-{case_id}-{index:03d}",
                case_id=case_id,
                statement=statement,
                subject=subject,
                predicate=predicate,
                value=value,
                source_node_ids=(node_ids[(index - 1) % len(node_ids)],),
                confidence=0.94,
                status=FactStatus.VERIFIED,
                extraction_method="synthetic_experience_fixture",
                uncertainty="合成案件，仅用于三个业务 Agent 的本地体验。",
            )
        )

    if scenario.conflicts:
        store.replace_conflicts(
            case_id,
            [
                EvidenceConflict(
                    conflict_id=f"CONFLICT-{case_id}-{index:02d}",
                    case_id=case_id,
                    subject="两轮车辆",
                    predicate=(
                        "登记类型" if index == 1 else "驶入方向"
                    ),
                    fact_ids=tuple(
                        f"FACT-{case_id}-{fact_index:03d}"
                        for fact_index in fact_indexes
                    ),
                    description=(
                        "不同案件材料对同一关键事实的记载冲突，"
                        "必须降置信度并等待人工核验。"
                    ),
                    severity="blocking",
                )
                for index, fact_indexes in enumerate(scenario.conflicts, start=1)
            ],
        )

    store.audit(
        case_id,
        "synthetic_business_experience_ready",
        {
            "scenario_id": scenario_id,
            "fact_count": len(scenario.fact_rows),
            "source_count": len(scenario.roles),
            "synthetic": True,
        },
        "experience_fixture",
    )
    return case_id, scenario

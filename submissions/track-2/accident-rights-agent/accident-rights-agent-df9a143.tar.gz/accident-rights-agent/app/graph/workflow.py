"""LangGraph case orchestrator with SQLite checkpoint recovery."""

from __future__ import annotations

import concurrent.futures
import hashlib
import json
import re
import sqlite3
import time
from datetime import date, timedelta
from pathlib import Path
from typing import Any, Callable

from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.graph import END, START, StateGraph
from pydantic import ValidationError

from app.agents.intake import assess_business_intake
from app.agents.liability import LiabilityAgent
from app.agents.model_adapter import (
    AgentModelAdapter,
    DeterministicAgentModelAdapter,
)
from app.agents.vehicle_nature import VehicleNatureAgent
from app.evidence.workspace import CaseWorkspace
from app.graph.verifier import CaseVerifier
from app.memory.context_builder import ContextBuilder
from app.memory.service import bootstrap_case_memory
from app.memory.store import CaseMemoryStore
from app.rag.retrieval import HybridLegalRetriever
from app.schemas.business import VehicleNatureResult
from app.schemas.legal import LegalCitation
from app.schemas.memory import CaseCapsule
from app.schemas.orchestration import CaseState, NodeResult, NodeStatus, utc_now

NODE_TIMEOUTS = {
    "intake_complete": 10,
    "evidence_ready": 10,
    "legal_retrieval": 60,
    "vehicle_nature": 30,
    "liability": 30,
    "rights_workflow": 30,
    "verifier": 30,
    "human_approval": 10,
    "missing_evidence": 10,
    "legal_conflict": 10,
    "low_confidence": 10,
    "node_failed": 10,
}

NODE_PROGRESS = {
    "intake_complete": 0.10,
    "evidence_ready": 0.20,
    "legal_retrieval": 0.35,
    "vehicle_nature": 0.50,
    "liability": 0.65,
    "rights_workflow": 0.78,
    "missing_evidence": 0.78,
    "legal_conflict": 0.78,
    "low_confidence": 0.78,
    "node_failed": 0.78,
    "verifier": 0.90,
    "human_approval": 1.0,
}


class SchemaNodeError(ValueError):
    pass


def _stable_hash(state: dict[str, Any]) -> str:
    excluded = {
        "node_results",
        "current_node",
        "progress",
        "route",
        "warnings",
        "errors",
    }
    payload = {key: value for key, value in state.items() if key not in excluded}
    encoded = json.dumps(
        payload, ensure_ascii=False, sort_keys=True, default=str
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_workdays(start: date, days: int) -> date:
    current = start
    added = 0
    while added < days:
        current += timedelta(days=1)
        if current.weekday() < 5:
            added += 1
    return current


class CaseOrchestrator:
    def __init__(
        self,
        *,
        workspace: CaseWorkspace,
        retriever: HybridLegalRetriever,
        checkpoint_path: Path | str = Path("data/checkpoints/orchestrator.sqlite3"),
        model_adapter: AgentModelAdapter | None = None,
    ):
        self.workspace = workspace
        self.retriever = retriever
        self.model_adapter = model_adapter or DeterministicAgentModelAdapter()
        self.vehicle_agent = VehicleNatureAgent(model_adapter=self.model_adapter)
        self.liability_agent = LiabilityAgent(model_adapter=self.model_adapter)
        self.checkpoint_path = Path(checkpoint_path)
        self.checkpoint_path.parent.mkdir(parents=True, exist_ok=True)
        self._checkpoint_connection = sqlite3.connect(
            self.checkpoint_path, check_same_thread=False
        )
        self._checkpointer = SqliteSaver(self._checkpoint_connection)

    def close(self) -> None:
        self._checkpoint_connection.close()

    def compile(self, *, interrupt_after: list[str] | None = None):
        graph = StateGraph(CaseState)
        workers: dict[str, Callable[[dict[str, Any]], dict[str, Any]]] = {
            "intake_complete": self._intake_complete,
            "evidence_ready": self._evidence_ready,
            "legal_retrieval": self._legal_retrieval,
            "vehicle_nature": self._vehicle_nature,
            "liability": self._liability,
            "rights_workflow": self._rights_workflow,
            "verifier": self._verifier,
            "human_approval": self._human_approval,
            "missing_evidence": lambda state: self._branch(state, "missing_evidence"),
            "legal_conflict": lambda state: self._branch(state, "legal_conflict"),
            "low_confidence": lambda state: self._branch(state, "low_confidence"),
            "node_failed": lambda state: self._branch(state, "node_failed"),
        }
        for name, worker in workers.items():
            graph.add_node(name, self._wrapped_node(name, worker))
        graph.add_edge(START, "intake_complete")
        graph.add_edge("intake_complete", "evidence_ready")
        graph.add_conditional_edges(
            "evidence_ready",
            self._route,
            {
                "legal_retrieval": "legal_retrieval",
                "missing_evidence": "missing_evidence",
                "node_failed": "node_failed",
            },
        )
        graph.add_conditional_edges(
            "legal_retrieval",
            self._route,
            {
                "vehicle_nature": "vehicle_nature",
                "legal_conflict": "legal_conflict",
                "node_failed": "node_failed",
            },
        )
        graph.add_conditional_edges(
            "vehicle_nature",
            self._route,
            {
                "liability": "liability",
                "low_confidence": "low_confidence",
                "node_failed": "node_failed",
            },
        )
        graph.add_conditional_edges(
            "liability",
            self._route,
            {
                "rights_workflow": "rights_workflow",
                "missing_evidence": "missing_evidence",
                "node_failed": "node_failed",
            },
        )
        graph.add_conditional_edges(
            "rights_workflow",
            self._route,
            {"verifier": "verifier", "node_failed": "node_failed"},
        )
        for branch in (
            "missing_evidence",
            "legal_conflict",
            "low_confidence",
            "node_failed",
        ):
            graph.add_edge(branch, "verifier")
        graph.add_edge("verifier", "human_approval")
        graph.add_edge("human_approval", END)
        return graph.compile(
            checkpointer=self._checkpointer,
            interrupt_after=interrupt_after,
        )

    def run(
        self,
        case_id: str,
        *,
        thread_id: str | None = None,
        interrupt_after: str | None = None,
        simulate_json_error_at: str | None = None,
    ) -> dict[str, Any]:
        selected_thread = thread_id or case_id
        initial: CaseState = {
            "case_id": case_id,
            "thread_id": selected_thread,
            "current_node": "pending",
            "progress": 0.0,
            "route": "intake_complete",
            "approval_status": "pending",
            "document_status": "draft",
            "interrupt_after": interrupt_after,
            "simulate_json_error_at": simulate_json_error_at,
            "node_results": {},
            "legal_queries": [],
            "legal_citations": [],
            "blocking_issues": [],
            "missing_evidence": [],
            "warnings": [],
            "errors": [],
        }
        graph = self.compile(
            interrupt_after=[interrupt_after] if interrupt_after else None
        )
        return graph.invoke(initial, {"configurable": {"thread_id": selected_thread}})

    def resume(self, thread_id: str) -> dict[str, Any]:
        graph = self.compile()
        return graph.invoke(None, {"configurable": {"thread_id": thread_id}})

    def status(self, thread_id: str) -> dict[str, Any]:
        graph = self.compile()
        snapshot = graph.get_state({"configurable": {"thread_id": thread_id}})
        values = dict(snapshot.values or {})
        return {
            "thread_id": thread_id,
            "case_id": values.get("case_id"),
            "current_node": values.get("current_node", "unknown"),
            "progress": values.get("progress", 0.0),
            "next": list(snapshot.next),
            "approval_status": values.get("approval_status"),
            "document_status": values.get("document_status"),
            "errors": values.get("errors", []),
            "recoverable": bool(snapshot.next),
            "node_results": values.get("node_results", {}),
        }

    @staticmethod
    def _route(state: CaseState) -> str:
        return state.get("route", "node_failed")

    def _wrapped_node(
        self,
        name: str,
        worker: Callable[[dict[str, Any]], dict[str, Any]],
    ) -> Callable[[CaseState], dict[str, Any]]:
        def run(state: CaseState) -> dict[str, Any]:
            state_dict: dict[str, Any] = dict(state)
            started = utc_now()
            inputs_hash = _stable_hash(state_dict)
            warnings: list[str] = []
            errors: list[str] = []
            outputs: dict[str, Any] = {}
            retry_count = 0
            status = NodeStatus.SUCCEEDED
            started_monotonic = time.perf_counter()
            for attempt in range(2):
                try:
                    if (
                        attempt == 0
                        and state_dict.get("simulate_json_error_at") == name
                    ):
                        raise SchemaNodeError("simulated malformed JSON/schema output")
                    with concurrent.futures.ThreadPoolExecutor(
                        max_workers=1
                    ) as executor:
                        future = executor.submit(worker, state_dict)
                        outputs = future.result(timeout=NODE_TIMEOUTS[name])
                    if not isinstance(outputs, dict):
                        raise SchemaNodeError("node output must be an object")
                    json.dumps(outputs, ensure_ascii=False, default=str)
                    warnings.extend(outputs.pop("warnings", []))
                    errors.extend(outputs.pop("errors", []))
                    break
                except (
                    SchemaNodeError,
                    ValidationError,
                    json.JSONDecodeError,
                ) as exc:
                    if attempt == 0:
                        retry_count = 1
                        warnings.append(
                            f"schema output repaired and retried once: {exc}"
                        )
                        continue
                    status = NodeStatus.FAILED
                    errors.append(f"{type(exc).__name__}: {exc}")
                    outputs = {"route": "node_failed"}
                except concurrent.futures.TimeoutError:
                    status = NodeStatus.FAILED
                    errors.append(
                        f"TimeoutError: {name} exceeded {NODE_TIMEOUTS[name]}s"
                    )
                    outputs = {"route": "node_failed"}
                    break
                except Exception as exc:
                    status = NodeStatus.FAILED
                    errors.append(f"{type(exc).__name__}: {exc}")
                    outputs = {"route": "node_failed"}
                    break
            finished = utc_now()
            duration_ms = round((time.perf_counter() - started_monotonic) * 1000, 3)
            result = NodeResult(
                status=status,
                started_at=started,
                finished_at=finished,
                inputs_hash=inputs_hash,
                outputs=outputs,
                warnings=warnings,
                errors=errors,
                retry_count=retry_count,
                metrics={
                    "duration_ms": duration_ms,
                    "timeout_seconds": NODE_TIMEOUTS[name],
                },
            )
            node_results = dict(state_dict.get("node_results", {}))
            node_results[name] = result.model_dump(mode="json")
            combined_warnings = list(state_dict.get("warnings", [])) + warnings
            combined_errors = list(state_dict.get("errors", [])) + errors
            return {
                **outputs,
                "current_node": name,
                "progress": NODE_PROGRESS[name],
                "node_results": node_results,
                "warnings": combined_warnings,
                "errors": combined_errors,
            }

        return run

    def _intake_complete(self, state: dict[str, Any]) -> dict[str, Any]:
        store = self.workspace.store(state["case_id"])
        exported = store.export_case(state["case_id"])
        assessment = assess_business_intake(
            store.list_sources(state["case_id"]),
            exported["facts"],
            evidence_nodes=exported["evidence_nodes"],
            conflicts=exported["conflicts"],
        )
        store.audit(
            state["case_id"],
            "business_intake_completed",
            {
                "uploaded_count": len(assessment.uploaded_materials),
                "blocking_issues": [
                    item.model_dump(mode="json") for item in assessment.blocking_issues
                ],
                "route_hint": assessment.route_hint,
            },
            "case_intake_agent",
        )
        return {
            "route": "evidence_ready",
            "intake_assessment": assessment.to_dict(),
            "blocking_issues": [
                item.model_dump(mode="json") for item in assessment.blocking_issues
            ],
            "missing_evidence": [
                item.model_dump(mode="json")
                for item in assessment.missing_required_materials
            ],
        }

    def _evidence_ready(self, state: dict[str, Any]) -> dict[str, Any]:
        store = self.workspace.store(state["case_id"])
        nodes = store.list_nodes(state["case_id"])
        facts = store.list_facts(state["case_id"])
        route = "legal_retrieval" if nodes and facts else "missing_evidence"
        return {
            "route": route,
            "evidence_summary": {
                "node_count": len(nodes),
                "fact_count": len(facts),
                "high_cost_parser_reexecuted": False,
            },
        }

    def _legal_retrieval(self, state: dict[str, Any]) -> dict[str, Any]:
        queries = state.get("legal_queries") or [
            "事故责任如何依据行为原因力和过错严重程度确定",
            "机动车与非机动车事故赔偿路径以及交强险商业险顺序",
            "事故认定复核期限和重新鉴定期限",
            "两轮电动车车辆属性国家标准与司法认定",
            "路口信号灯 标志标线 让行义务 逆行 横穿 观察 制动 原因力",
        ]
        citations: dict[str, LegalCitation] = {}
        for query in queries:
            for citation in self.retriever.citations(query, top_k=4, candidate_k=10):
                citations[citation.source_id] = citation
        route = "vehicle_nature" if citations else "legal_conflict"
        return {
            "route": route,
            "legal_queries": list(queries),
            "legal_citations": [
                item.model_dump(mode="json") for item in citations.values()
            ],
        }

    def _memory_context(
        self, state: dict[str, Any], task: str, node_name: str
    ) -> tuple[CaseMemoryStore, CaseCapsule, dict[str, Any]]:
        memory, capsule = bootstrap_case_memory(self.workspace, state["case_id"])
        evidence_facts = self.workspace.store(state["case_id"]).list_facts(
            state["case_id"]
        )
        citations = [
            LegalCitation.model_validate(item)
            for item in state.get("legal_citations", [])
        ]
        context = ContextBuilder(memory).build(
            task=task,
            capsule=capsule,
            facts=evidence_facts,
            citations=citations,
            node_name=node_name,
        )
        return memory, capsule, context.model_dump(mode="json")

    def _vehicle_nature(self, state: dict[str, Any]) -> dict[str, Any]:
        memory, capsule, context = self._memory_context(
            state, "判断两轮车辆法律属性、登记与技术参数证据", "vehicle_nature"
        )
        store = self.workspace.store(state["case_id"])
        exported = store.export_case(state["case_id"])
        facts = _facts_with_memory_status(memory, exported["facts"])
        citations = [
            LegalCitation.model_validate(item)
            for item in state.get("legal_citations", [])
        ]
        result = self.vehicle_agent.run(
            facts=facts,
            legal_citations=citations,
            conflicts=exported["conflicts"],
            accident_date=_extract_accident_date(exported["facts"]),
        )
        output = result.model_dump(mode="json")
        compact = {
            "classification": result.classification.value,
            "confidence": result.confidence,
            "conclusion_status": result.conclusion_status,
            "warning": result.warning,
        }
        updated = capsule.model_copy(
            update={
                "vehicle_classification": output,
                "missing_evidence": [item.reason for item in result.missing_evidence],
                "citations": citations[:8],
                "last_updated_by": "vehicle_nature",
                "version": capsule.version + 1,
            }
        )
        memory.save_capsule(updated)
        memory.append_event(
            "vehicle_nature_completed",
            "vehicle_nature_agent",
            {
                "classification": result.classification.value,
                "confidence": result.confidence,
                "conclusion_status": result.conclusion_status,
                "supporting_fact_ids": [
                    item.fact_id for item in result.supporting_facts
                ],
                "ruleset_id": self.vehicle_agent.rule_engine.ruleset_id,
            },
        )
        store.audit(
            state["case_id"],
            "vehicle_nature_completed",
            {
                "classification": result.classification.value,
                "confidence": result.confidence,
                "fact_ids": [
                    item.fact_id
                    for item in [
                        *result.supporting_facts,
                        *result.contradicting_facts,
                    ]
                ],
                "law_ids": [item.source_id for item in result.legal_basis],
            },
            "vehicle_nature_agent",
        )
        return {
            "route": "liability",
            "vehicle_classification": compact,
            "vehicle_nature_result": output,
            "parameter_comparison": [
                item.model_dump(mode="json") for item in result.parameter_comparison
            ],
            "missing_evidence": [
                item.model_dump(mode="json") for item in result.missing_evidence
            ],
            "case_capsule": updated.model_dump(mode="json"),
            "context_metrics": {
                "before_tokens": context["before_token_count"],
                "after_tokens": context["after_token_count"],
            },
            "protected_fields_valid": True,
        }

    def _liability(self, state: dict[str, Any]) -> dict[str, Any]:
        memory, capsule, context = self._memory_context(
            state, "分析违法行为、原因力、事故责任与赔偿路径", "liability"
        )
        store = self.workspace.store(state["case_id"])
        exported = store.export_case(state["case_id"])
        facts = _facts_with_memory_status(memory, exported["facts"])
        citations = [
            LegalCitation.model_validate(item)
            for item in state.get("legal_citations", [])
        ]
        vehicle_result = VehicleNatureResult.model_validate(
            state["vehicle_nature_result"]
        )
        result = self.liability_agent.run(
            facts=facts,
            legal_citations=citations,
            vehicle_nature=vehicle_result,
            conflicts=exported["conflicts"],
        )
        hypotheses = [
            item.model_dump(mode="json") for item in result.liability_hypotheses
        ]
        updated = capsule.model_copy(
            update={
                "liability_hypotheses": hypotheses,
                "missing_evidence": [item.reason for item in result.missing_evidence],
                "last_updated_by": "liability",
                "version": capsule.version + 1,
            }
        )
        memory.save_capsule(updated)
        memory.append_event(
            "liability_completed",
            "liability_agent",
            {
                "responsibility_probabilities": (result.responsibility_probabilities),
                "compensation_regime": result.compensation_regime.value,
                "unique_conclusion_blocked": (
                    result.uncertainty.unique_conclusion_blocked
                ),
            },
        )
        store.audit(
            state["case_id"],
            "liability_completed",
            {
                "hypotheses": [
                    {
                        "id": item.hypothesis_id,
                        "probability": item.probability,
                    }
                    for item in result.liability_hypotheses
                ],
                "evidence_ids": sorted(
                    {
                        evidence_id
                        for item in result.key_evidence
                        for evidence_id in item.evidence_ids
                    }
                ),
                "law_ids": [item.source_id for item in result.legal_basis],
            },
            "liability_agent",
        )
        payload = result.model_dump(mode="json")
        return {
            "route": (
                "missing_evidence"
                if result.uncertainty.unique_conclusion_blocked
                else "rights_workflow"
            ),
            "liability_hypotheses": hypotheses,
            "liability_result": payload,
            "violation_matrix": payload["violation_matrix"],
            "causation_matrix": payload["causation_matrix"],
            "responsibility_probabilities": (payload["responsibility_probabilities"]),
            "accident_responsibility": payload["accident_responsibility"],
            "civil_compensation_allocation": (payload["civil_compensation_allocation"]),
            "insurance_payment_estimate": (payload["insurance_payment_estimate"]),
            "counterfactual_analysis": payload["counterfactual_analysis"],
            "missing_evidence": payload["missing_evidence"],
            "case_capsule": updated.model_dump(mode="json"),
            "context_metrics": {
                "before_tokens": context["before_token_count"],
                "after_tokens": context["after_token_count"],
            },
            "protected_fields_valid": True,
        }

    def _rights_workflow(self, state: dict[str, Any]) -> dict[str, Any]:
        memory, capsule, context = self._memory_context(
            state, "识别复核与重新鉴定期限，形成待人工批准任务", "rights_workflow"
        )
        text = json.dumps(context["facts"], ensure_ascii=False)
        date_match = re.search(r"(?:送达日期|送达时间)\D{0,5}(\d{4}-\d{2}-\d{2})", text)
        deadlines: list[dict[str, Any]] = []
        if date_match:
            served = date.fromisoformat(date_match.group(1))
            due = _add_workdays(served, 3)
            deadlines.append(
                {
                    "type": "事故认定复核申请",
                    "served_date": served.isoformat(),
                    "deadline": due.isoformat(),
                    "calculation": "送达之日起三个工作日；节假日表需部署地复核",
                    "law_id": next(
                        (
                            item["source_id"]
                            for item in state.get("legal_citations", [])
                            if item.get("article_no") == "第七十一条"
                        ),
                        "",
                    ),
                }
            )
        actions = [
            {
                "action": "核对事故认定书送达日期并准备复核材料",
                "status": "draft",
                "requires_human_approval": True,
            },
            {
                "action": "申请复制案卷并固定行车记录仪原文件",
                "status": "draft",
                "requires_human_approval": True,
            },
        ]
        updated = capsule.model_copy(
            update={
                "rights_deadlines": deadlines,
                "next_actions": actions,
                "last_updated_by": "rights_workflow",
                "version": capsule.version + 1,
            }
        )
        memory.save_capsule(updated)
        return {
            "route": "verifier",
            "rights_tasks": actions,
            "case_capsule": updated.model_dump(mode="json"),
            "document_status": "draft",
            "context_metrics": {
                "before_tokens": context["before_token_count"],
                "after_tokens": context["after_token_count"],
            },
            "protected_fields_valid": True,
        }

    def _verifier(self, state: dict[str, Any]) -> dict[str, Any]:
        verifier = CaseVerifier(
            self.workspace, self.retriever.corpus, as_of=date.today()
        )
        result = verifier.verify(state)
        return {
            "route": "human_approval",
            "verifier_results": result,
            "document_status": "draft",
        }

    @staticmethod
    def _human_approval(state: dict[str, Any]) -> dict[str, Any]:
        return {
            "route": "complete",
            "approval_status": "pending",
            "document_status": "draft",
            "human_action_required": True,
        }

    @staticmethod
    def _branch(state: dict[str, Any], reason: str) -> dict[str, Any]:
        warning = {
            "missing_evidence": "证据不足，责任结论保持不确定并转人工补件。",
            "legal_conflict": "法律引用缺失或冲突，禁止确定性法律结论。",
            "low_confidence": "车辆属性置信度过低，转人工核验。",
            "node_failed": "节点明确失败，可从最近成功检查点恢复。",
        }[reason]
        return {
            "route": "verifier",
            "branch_reason": reason,
            "warnings": [warning],
            "document_status": "draft",
        }


def _extract_accident_date(facts: list[dict[str, Any]]) -> date | None:
    for fact in facts:
        text = " ".join(
            str(fact.get(key, "")) for key in ("statement", "predicate", "value")
        )
        if not any(keyword in text for keyword in ("事故日期", "事故时间", "事发时间")):
            continue
        match = re.search(r"(\d{4})[-年/](\d{1,2})[-月/](\d{1,2})日?", text)
        if match:
            try:
                return date(
                    int(match.group(1)),
                    int(match.group(2)),
                    int(match.group(3)),
                )
            except ValueError:
                continue
    return None


def _facts_with_memory_status(
    memory: CaseMemoryStore, facts: list[dict[str, Any]]
) -> list[dict[str, Any]]:
    """Project append-only Fact Memory status into the shared fact payload."""

    projected = []
    for fact in facts:
        item = dict(fact)
        try:
            item["status"] = memory.fact_status(str(fact["fact_id"])).value
        except KeyError:
            # bootstrap_case_memory registers all current Evidence Graph facts;
            # this fallback remains fail-soft for a concurrent evidence append.
            item["status"] = str(fact.get("status", "unverified"))
        projected.append(item)
    return projected

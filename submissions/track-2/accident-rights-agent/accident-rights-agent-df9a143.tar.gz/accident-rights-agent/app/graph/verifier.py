"""Fail-closed policy checks before the human approval node."""

from __future__ import annotations

from datetime import date
from typing import Any

from app.evidence.workspace import CaseWorkspace
from app.memory.protected_fields import assert_protected_fields_preserved
from app.rag.corpus import LegalCorpusStore
from app.schemas.business import (
    CompensationRegime,
    LiabilityResult,
    VehicleNatureClassification,
    VehicleNatureResult,
    ViolationStatus,
)
from app.schemas.legal import LegalCitation

DETERMINISTIC_MARKERS = (
    "必然属于机动车",
    "一定主责",
    "保证胜诉",
    "保证复核成功",
    "保险公司一定少赔",
    "已提交",
    "已发送",
)


class CaseVerifier:
    def __init__(
        self,
        workspace: CaseWorkspace,
        corpus: LegalCorpusStore,
        *,
        as_of: date | None = None,
    ):
        self.workspace = workspace
        self.corpus = corpus
        self.as_of = as_of or date.today()

    def verify(self, state: dict[str, Any]) -> dict[str, Any]:
        case_id = state["case_id"]
        evidence = self.workspace.store(case_id).export_case(case_id)
        valid_evidence_ids = {item["source_id"] for item in evidence["sources"]} | {
            item["node_id"] for item in evidence["evidence_nodes"]
        }
        valid_fact_ids = {item["fact_id"] for item in evidence["facts"]}
        checks: dict[str, dict[str, Any]] = {}
        vehicle_result = None
        liability_result = None
        schema_errors: list[str] = []
        try:
            if state.get("vehicle_nature_result"):
                vehicle_result = VehicleNatureResult.model_validate(
                    state["vehicle_nature_result"]
                )
            if state.get("liability_result"):
                liability_result = LiabilityResult.model_validate(
                    state["liability_result"]
                )
        except Exception as exc:
            schema_errors.append(f"{type(exc).__name__}: {exc}")
        checks["business_schemas"] = {
            "passed": not schema_errors,
            "errors": schema_errors,
        }

        referenced_evidence: set[str] = set()
        referenced_facts: set[str] = set()
        nested_citation_payloads: list[dict[str, Any]] = []
        if vehicle_result:
            for reference in [
                *vehicle_result.supporting_facts,
                *vehicle_result.contradicting_facts,
            ]:
                referenced_facts.add(reference.fact_id)
                referenced_evidence.update(reference.evidence_ids)
            for comparison in vehicle_result.parameter_comparison:
                referenced_facts.update(comparison.fact_ids)
                referenced_evidence.update(comparison.evidence_ids)
            for factor in [
                *vehicle_result.registration_and_management_factors,
                *vehicle_result.appraisal_factors,
            ]:
                referenced_facts.update(factor.fact_ids)
                referenced_evidence.update(factor.evidence_ids)
            nested_citation_payloads.extend(
                item.model_dump(mode="json") for item in vehicle_result.legal_basis
            )
        if liability_result:
            for finding in liability_result.violation_matrix:
                referenced_facts.update(finding.fact_ids)
                referenced_evidence.update(finding.evidence_ids)
                nested_citation_payloads.extend(
                    item.model_dump(mode="json") for item in finding.law_citations
                )
            for reference in liability_result.key_evidence:
                referenced_facts.add(reference.fact_id)
                referenced_evidence.update(reference.evidence_ids)
            nested_citation_payloads.extend(
                item.model_dump(mode="json")
                for item in [
                    *liability_result.legal_basis,
                    *liability_result.civil_compensation_allocation.legal_basis,
                ]
            )
        else:
            referenced_evidence.update(
                value
                for hypothesis in state.get("liability_hypotheses", [])
                for value in hypothesis.get("evidence_ids", [])
            )
        missing_evidence = sorted(referenced_evidence - valid_evidence_ids)
        checks["evidence_ids"] = {
            "passed": not missing_evidence,
            "missing": missing_evidence,
        }
        missing_facts = sorted(referenced_facts - valid_fact_ids)
        checks["fact_ids"] = {
            "passed": not missing_facts,
            "missing": missing_facts,
        }

        citations: list[LegalCitation] = []
        citation_errors: list[str] = []
        unique_citation_payloads = {
            payload.get("source_id", f"unknown-{index}"): payload
            for index, payload in enumerate(
                [
                    *state.get("legal_citations", []),
                    *nested_citation_payloads,
                ]
            )
        }
        for payload in unique_citation_payloads.values():
            try:
                citation = LegalCitation.model_validate(payload)
                indexed = self.corpus.get_chunk(citation.source_id)
                if indexed.content_hash == "":
                    raise ValueError("empty indexed hash")
                if not citation.is_applicable(self.as_of):
                    raise ValueError(
                        "citation is expired or not effective as of run date"
                    )
                citations.append(citation)
            except Exception as exc:
                citation_errors.append(f"{payload.get('source_id', '?')}: {exc}")
        checks["legal_citations"] = {
            "passed": bool(citations) and not citation_errors,
            "errors": citation_errors,
            "count": len(citations),
        }

        vehicle = state.get("vehicle_classification", {})
        hypotheses = state.get("liability_hypotheses", [])
        if liability_result:
            regimes = {liability_result.compensation_regime.value}
        else:
            regimes = {item.get("compensation_regime") for item in hypotheses if item}
        classification = vehicle.get("classification")
        vehicle_conflict = (
            classification == VehicleNatureClassification.NON_MOTOR_VEHICLE.value
            and CompensationRegime.MOTOR_VS_MOTOR.value in regimes
        ) or (
            classification == VehicleNatureClassification.MOTOR_VEHICLE.value
            and CompensationRegime.MOTOR_VS_NON_MOTOR_OR_PEDESTRIAN.value in regimes
        )
        checks["vehicle_compensation_consistency"] = {
            "passed": not vehicle_conflict,
            "classification": vehicle.get("classification"),
            "regimes": sorted(value for value in regimes if value),
        }

        unsupported = []
        if liability_result:
            for finding in liability_result.violation_matrix:
                if finding.status is ViolationStatus.CONFIRMED and not (
                    finding.fact_ids and finding.evidence_ids and finding.law_citations
                ):
                    unsupported.append(finding.behavior_id)
        else:
            for hypothesis in hypotheses:
                if hypothesis.get("certainty") == "deterministic" and not (
                    hypothesis.get("evidence_ids") and hypothesis.get("citation_ids")
                ):
                    unsupported.append(hypothesis.get("label", "unnamed"))
        checks["fact_compatibility"] = {
            "passed": not unsupported and (bool(valid_fact_ids) or not hypotheses),
            "unsupported": unsupported,
            "available_fact_count": len(valid_fact_ids),
        }

        rendered = str(state)
        risky = [marker for marker in DETERMINISTIC_MARKERS if marker in rendered]
        checks["no_unsupported_determinism"] = {
            "passed": not risky,
            "markers": risky,
        }
        try:
            protected = state.get("case_capsule", {})
            envelope = {
                "case_capsule": protected,
                "node_results": state.get("node_results", {}),
            }
            assert_protected_fields_preserved(envelope, envelope)
            protected_ok = bool(state.get("protected_fields_valid"))
            protected_error = (
                "" if protected_ok else "No successful protected-field context audit."
            )
        except Exception as exc:
            protected_ok = False
            protected_error = str(exc)
        checks["protected_fields"] = {
            "passed": protected_ok,
            "error": protected_error,
        }
        passed = all(item["passed"] for item in checks.values())
        return {
            "passed": passed,
            "checks": checks,
            "blocking_reasons": [
                name for name, result in checks.items() if not result["passed"]
            ],
        }

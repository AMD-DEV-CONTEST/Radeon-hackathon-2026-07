"""Task-scoped context construction with measurable compression."""

from __future__ import annotations

import json
from typing import Any, Sequence

from app.memory.protected_fields import (
    assert_protected_fields_preserved,
    collect_protected_fields,
)
from app.memory.store import CaseMemoryStore
from app.rag.embeddings import tokenize
from app.schemas.legal import LegalCitation
from app.schemas.memory import CaseCapsule, ContextBundle


def estimate_tokens(value: Any) -> int:
    text = (
        value
        if isinstance(value, str)
        else json.dumps(value, ensure_ascii=False, sort_keys=True)
    )
    # Conservative multilingual approximation used for before/after metrics.
    return max(1, (len(text) + 1) // 2)


def relevance(query: str, value: Any) -> float:
    query_tokens = set(tokenize(query))
    candidate = json.dumps(value, ensure_ascii=False, sort_keys=True)
    candidate_tokens = set(tokenize(candidate))
    return len(query_tokens & candidate_tokens) / max(1, len(query_tokens))


class ContextBuilder:
    def __init__(self, memory_store: CaseMemoryStore):
        self.memory_store = memory_store

    def build(
        self,
        *,
        task: str,
        capsule: CaseCapsule,
        facts: Sequence[dict[str, Any]],
        citations: Sequence[LegalCitation],
        top_k_facts: int = 8,
        top_k_citations: int = 4,
        node_name: str = "unknown",
    ) -> ContextBundle:
        before = {
            "capsule": capsule.model_dump(mode="json"),
            "facts": list(facts),
            "citations": [
                item.model_dump(mode="json") for item in citations
            ],
        }
        selected_facts = sorted(
            facts, key=lambda item: relevance(task, item), reverse=True
        )[:top_k_facts]
        selected_citations = sorted(
            citations,
            key=lambda item: relevance(task, item.model_dump(mode="json")),
            reverse=True,
        )[:top_k_citations]
        protected = collect_protected_fields(before)
        protected_values: dict[str, list[str]] = {}
        for item in protected:
            protected_values.setdefault(item.kind.value, []).append(item.value)
        after = {
            "capsule": capsule.model_dump(mode="json"),
            "facts": selected_facts,
            "citations": [
                item.model_dump(mode="json") for item in selected_citations
            ],
            # The kind-keyed mirror makes values such as document versions and
            # approval states independently discoverable by the fail-closed
            # validator after task-scoped context selection. Source paths stay
            # in the audit-only ContextBundle field and do not consume prompt
            # tokens.
            "protected_values": {
                kind: sorted(set(values))
                for kind, values in protected_values.items()
            },
        }
        assert_protected_fields_preserved(before, after)
        bundle = ContextBundle(
            case_id=self.memory_store.case_id,
            task=task,
            capsule=capsule,
            facts=list(selected_facts),
            citations=list(selected_citations),
            before_token_count=estimate_tokens(before),
            after_token_count=estimate_tokens(after),
            protected_fields=protected,
        )
        self.memory_store.record_working_context(
            node_name,
            bundle.model_dump(mode="json"),
            before_tokens=bundle.before_token_count,
            after_tokens=bundle.after_token_count,
        )
        return bundle

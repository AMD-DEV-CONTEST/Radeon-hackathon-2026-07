"""Accident Rights Agent."""

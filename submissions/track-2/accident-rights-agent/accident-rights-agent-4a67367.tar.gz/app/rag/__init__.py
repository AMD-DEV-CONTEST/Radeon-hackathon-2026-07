"""Versioned local legal retrieval."""

"""Local Gradio user interface."""

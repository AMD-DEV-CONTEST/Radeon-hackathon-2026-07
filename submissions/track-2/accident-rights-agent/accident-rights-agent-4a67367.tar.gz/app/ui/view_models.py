"""Pure view-model functions for Gradio and regression tests."""

from __future__ import annotations

import json
from typing import Any

UI_NODES = (
    ("intake", "intake_complete"),
    ("evidence", "evidence_ready"),
    ("legal_retrieval", "legal_retrieval"),
    ("vehicle_nature", "vehicle_nature"),
    ("liability", "liability"),
    ("rights_workflow", "rights_workflow"),
    ("verifier", "verifier"),
    ("human_approval", "human_approval"),
)


def progress_rows(state: dict[str, Any]) -> list[list[Any]]:
    results = state.get("node_results", {})
    rows: list[list[Any]] = []
    for label, backend_name in UI_NODES:
        result = results.get(backend_name)
        if not result:
            rows.append([label, "pending", "", "", 0, "", ""])
            continue
        raw_status = result.get("status", "pending")
        warnings = result.get("warnings", [])
        if raw_status == "succeeded" and warnings:
            display_status = "warning"
        else:
            display_status = raw_status
        if (
            label == "human_approval"
            and state.get("policy_gate", {}).get("decision") == "block"
        ):
            display_status = "blocked"
        outputs = result.get("outputs", {})
        summary = _summary(outputs)
        reason = "; ".join(result.get("errors", []))
        rows.append(
            [
                label,
                display_status,
                result.get("started_at", ""),
                result.get("finished_at", ""),
                result.get("retry_count", 0),
                summary,
                reason,
            ]
        )
    return rows


def progress_overview(
    state: dict[str, Any], *, recoverable: bool, next_nodes: list[str]
) -> dict[str, Any]:
    results = state.get("node_results", {})
    failed = [
        name
        for name, result in results.items()
        if result.get("status") == "failed"
    ]
    return {
        "case_id": state.get("case_id"),
        "thread_id": state.get("thread_id"),
        "progress_percent": round(float(state.get("progress", 0.0)) * 100, 1),
        "current_node": state.get("current_node", "pending"),
        "latest_checkpoint": state.get("current_node", "pending"),
        "recoverable": recoverable,
        "next_nodes": next_nodes,
        "failed_nodes": failed,
        "warning_count": len(state.get("warnings", [])),
        "error_count": len(state.get("errors", [])),
    }


def evidence_timeline_rows(
    case: dict[str, Any],
    *,
    phase: str = "全部",
    source_filter: str = "全部",
    status_filter: str = "全部",
) -> list[list[Any]]:
    nodes = {item["node_id"]: item for item in case.get("evidence_nodes", [])}
    sources = {item["source_id"]: item for item in case.get("sources", [])}
    conflicts_by_fact: dict[str, list[str]] = {}
    for conflict in case.get("conflicts", []):
        for fact_id in conflict.get("fact_ids", []):
            conflicts_by_fact.setdefault(fact_id, []).append(
                conflict.get("conflict_id", "")
            )
    events = case.get("timeline", [])
    phase_by_node: dict[str, str] = {}
    for index, event in enumerate(events):
        selected_phase = _phase(event.get("label", ""), index, len(events))
        for node_id in event.get("source_node_ids", []):
            phase_by_node[node_id] = selected_phase

    rows: list[list[Any]] = []
    for fact in case.get("facts", []):
        node_ids = fact.get("source_node_ids", [])
        linked_nodes = [nodes.get(node_id, {}) for node_id in node_ids]
        source_ids = sorted(
            {
                node.get("source_id")
                for node in linked_nodes
                if node.get("source_id")
            }
        )
        selected_phase = next(
            (
                phase_by_node[node_id]
                for node_id in node_ids
                if node_id in phase_by_node
            ),
            "阶段不确定",
        )
        display_status = {
            "verified": "confirmed",
            "unverified": "unverified",
            "disputed": "disputed",
            "rejected": "rejected",
        }.get(fact.get("status", ""), fact.get("status", "unverified"))
        source_roles = sorted(
            {
                _enum_value(sources[source_id]["role"])
                for source_id in source_ids
                if source_id in sources
            }
        )
        if phase != "全部" and selected_phase != phase:
            continue
        if source_filter != "全部" and source_filter not in source_roles:
            continue
        if status_filter != "全部" and display_status != status_filter:
            continue
        locator = [
            node.get("locator", {})
            for node in linked_nodes
            if node
        ]
        rows.append(
            [
                selected_phase,
                fact.get("fact_id"),
                ", ".join(source_ids),
                ", ".join(node_ids),
                json.dumps(locator, ensure_ascii=False, default=str),
                fact.get("statement"),
                round(float(fact.get("confidence", 0.0)), 3),
                display_status,
                ", ".join(conflicts_by_fact.get(fact.get("fact_id"), [])),
            ]
        )
    return rows


def evidence_preview_choices(case: dict[str, Any]) -> list[tuple[str, str]]:
    return [
        (
            f"{item['source_id']} · {item['original_name']} · {item['role']}",
            item["source_id"],
        )
        for item in case.get("sources", [])
    ]


def liability_view(state: dict[str, Any]) -> dict[str, Any]:
    vehicle = state.get("vehicle_nature_result") or state.get(
        "vehicle_classification", {}
    )
    liability = state.get("liability_result", {})
    return {
        "vehicle_nature": {
            **vehicle,
            "parameter_comparison": state.get("parameter_comparison", []),
        },
        "accident_responsibility": liability.get(
            "accident_responsibility",
            state.get("accident_responsibility", {}),
        ),
        "civil_compensation_allocation": liability.get(
            "civil_compensation_allocation",
            state.get("civil_compensation_allocation", {}),
        ),
        "insurance_payment_estimate": liability.get(
            "insurance_payment_estimate",
            state.get(
                "insurance_payment_estimate",
                {"status": "insufficient_data"},
            ),
        ),
        "compensation_regime": liability.get("compensation_regime")
        or state.get("compensation_route_result", {}).get(
            "compensation_regime"
        )
        or "pending_vehicle_classification",
        "violation_matrix": state.get("violation_matrix", []),
        "causation_matrix": state.get("causation_matrix", []),
        "liability_hypotheses": state.get("liability_hypotheses", []),
        "responsibility_probabilities": state.get(
            "responsibility_probabilities", {}
        ),
        "counterfactual_analysis": state.get(
            "counterfactual_analysis", []
        ),
        "verifier": state.get("verifier_results", {}),
        "policy_gate": state.get("policy_gate", {}),
        "citation_chain": {
            "fact_ids": _collect_ids(state, "fact_ids"),
            "evidence_ids": _collect_ids(state, "evidence_ids"),
            "law_ids": _collect_ids(state, "law_ids")
            or [
                item.get("law_id")
                for item in state.get("legal_citations", [])
                if item.get("law_id")
            ],
        },
    }


def rights_view(state: dict[str, Any]) -> dict[str, Any]:
    priority_rank = {
        "critical": 0,
        "high": 1,
        "medium": 2,
        "low": 3,
        "P0": 0,
        "P1": 1,
        "P2": 2,
    }
    tasks = sorted(
        state.get("rights_tasks", []),
        key=lambda item: (
            priority_rank.get(item.get("priority"), 9),
            item.get("due_at") or "9999",
        ),
    )
    deadlines = sorted(
        state.get("deadlines", []),
        key=lambda item: item.get("due_at") or "9999",
    )
    return {
        "delivery_date": state.get("delivery_date_result", {}),
        "appraisal_delivery_date": state.get(
            "appraisal_delivery_date_result", {}
        ),
        "deadlines": deadlines,
        "tasks": tasks,
        "evidence_collection_plan": state.get(
            "evidence_collection_plan", []
        ),
        "review_application_draft": state.get(
            "review_application_draft", {}
        ),
    }


def approval_view(state: dict[str, Any]) -> dict[str, Any]:
    gate = state.get("policy_gate", {})
    draft = state.get("review_application_draft", {})
    approval = state.get("approval_state", {})
    blocked_reasons = [
        *gate.get("blocking_issues", []),
        *draft.get("blocking_fields", []),
        *draft.get("not_submittable_reasons", []),
    ]
    return {
        "draft": draft,
        "key_facts": draft.get("facts", []),
        "responsibility_conclusion": state.get(
            "accident_responsibility", {}
        ),
        "policy_gate": gate,
        "risk_warnings": [
            *gate.get("warnings", []),
            *draft.get("risk_language_findings", []),
        ],
        "approval": approval,
        "can_approve": (
            gate.get("decision") != "block"
            and not draft.get("blocking_fields")
            and not draft.get("not_submittable_reasons")
            and bool(draft)
        ),
        "blocked_reasons": blocked_reasons,
        "display_document_status": (
            "approved_for_manual_submission"
            if approval.get("state") == "approved"
            else "draft"
        ),
    }


def audit_rows(
    case: dict[str, Any],
    *,
    node_filter: str = "全部",
    event_filter: str = "全部",
    result_filter: str = "全部",
) -> list[list[Any]]:
    rows: list[list[Any]] = []
    for event in case.get("audit_events", []):
        payload = redact_sensitive(event.get("payload", {}))
        node = str(payload.get("node") or payload.get("current_node") or "")
        event_type = event.get("event_type", "")
        result = str(
            payload.get("status")
            or payload.get("decision")
            or payload.get("result")
            or "recorded"
        )
        if node_filter != "全部" and node != node_filter:
            continue
        if event_filter != "全部" and event_type != event_filter:
            continue
        if result_filter != "全部" and result != result_filter:
            continue
        rows.append(
            [
                event.get("created_at"),
                event.get("actor"),
                event_type,
                event.get("case_id"),
                node,
                payload.get("inputs_hash", ""),
                result,
                payload.get("duration_ms", ""),
                _related_ids(payload),
                json.dumps(payload, ensure_ascii=False, default=str),
            ]
        )
    return rows


def redact_sensitive(value: Any, key: str = "") -> Any:
    sensitive_tokens = (
        "name",
        "phone",
        "mobile",
        "identity",
        "id_number",
        "address",
        "plate_number",
        "applicant",
    )
    if any(token in key.lower() for token in sensitive_tokens):
        return "***"
    if isinstance(value, dict):
        return {
            item_key: redact_sensitive(item, item_key)
            for item_key, item in value.items()
        }
    if isinstance(value, list):
        return [redact_sensitive(item, key) for item in value]
    return value


def _summary(value: dict[str, Any]) -> str:
    keys: list[str] = [
        key
        for key in (
            "route",
            "branch_reason",
            "approval_status",
            "document_status",
            "classification",
            "compensation_regime",
        )
        if key in value
    ]
    if not keys:
        keys = list(value)[:4]
    return "; ".join(f"{key}={value.get(key)}" for key in keys)


def _phase(label: str, index: int, total: int) -> str:
    if "碰撞前" in label:
        return "碰撞前"
    if "碰撞时" in label or "碰撞点" in label:
        return "碰撞时"
    if "碰撞后" in label:
        return "碰撞后"
    if total >= 3:
        if index == 0:
            return "碰撞前"
        if index == total - 1:
            return "碰撞后"
        return "碰撞时"
    return "阶段不确定"


def _collect_ids(value: Any, key_name: str) -> list[str]:
    result: set[str] = set()
    if isinstance(value, dict):
        for key, item in value.items():
            if key == key_name and isinstance(item, list):
                result.update(str(identifier) for identifier in item)
            result.update(_collect_ids(item, key_name))
    elif isinstance(value, list):
        for item in value:
            result.update(_collect_ids(item, key_name))
    return sorted(result)


def _related_ids(payload: dict[str, Any]) -> str:
    found: set[str] = set()
    for key, value in payload.items():
        if key.endswith("_id") and value:
            found.add(str(value))
        elif key.endswith("_ids") and isinstance(value, list):
            found.update(str(item) for item in value)
    return ", ".join(sorted(found))


def _enum_value(value: Any) -> str:
    return str(value.value if hasattr(value, "value") else value)

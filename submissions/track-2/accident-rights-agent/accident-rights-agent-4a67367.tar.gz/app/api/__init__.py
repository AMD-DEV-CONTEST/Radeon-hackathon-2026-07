"""Local FastAPI surface."""

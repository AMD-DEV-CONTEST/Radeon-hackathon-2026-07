# AMD 环境与本地模型执行日志

记录规范：每一步必须包含命令/操作、可核验输出、失败原因和下一步。不得记录 API Key、登录凭据或其他密钥。

## 2026-07-28 / STEP-01 / 官方指南核对

- 状态：完成
- 来源：AMD 官方比赛仓库 `Radeon-Cloud-User Guide/README.md`
- 来源版本：Git blob SHA `2bdb95ab205c426eb85fa516fee3a8e2351fe89f`
- 核对结果：
  - 持久化存储需在模板中选择 `Storage = Persistent (PVC)`。
  - Notebook 提供完整 Linux Terminal/JupyterLab，可在实例内部启动服务。
  - 公共 Qwen/DeepSeek API 是共享远程端点，不进入本项目核心链路。
  - 平台 `Deploy Type = vLLM Model API` 要求 `--host 0.0.0.0 --port 8000`，与本项目“模型仅监听回环地址”要求冲突。
- 失败原因：无。
- 下一步：使用 Notebook/GPU 模板 + PVC；进入实例后以 `127.0.0.1:8000` 启动 vLLM。

## 2026-07-28 / STEP-02 / Radeon Cloud 当前资源检查

- 状态：阻塞
- 操作：打开 `https://radeon-global.anruicloud.com/` 并读取页面状态。
- 可核验输出：页面标题为 `Radeon Cloud`，URL 已打开。
- 失败原因：当前 in-app Browser 会话在读取 DOM 和截图时连续超时，无法确认登录状态、现有模板或 Active Instance。
- 下一步：请用户在已打开的 Radeon Cloud 页面完成登录并检查/创建带 PVC 的 Notebook GPU 实例；任何 `Add Template`、`Launch` 或费用确认动作由用户接管。完成后提供 Notebook Terminal 或 SSH 访问方式，再执行环境指纹。

## 2026-07-28 / STEP-03 / 官方兼容性信息核对

- 状态：完成
- 可核验结果：
  - vLLM 官方文档当前列出 ROCm 6.3+；预编译 ROCm wheel 要求 Python 3.12，当前提供 ROCm 7.0/7.2.1 路径。
  - vLLM 支持模型列表包含 `Qwen3VLForConditionalGeneration` 和 `Qwen2_5_VLForConditionalGeneration`，二者均支持文本、图片和视频输入。
  - Qwen3-VL 官方 vLLM recipe 要求 vLLM `>=0.11.0`；其 AMD 专项 recipe 明确验证的是 MI300X/MI325X/MI355X。
  - Qwen2.5-VL-7B 模型页提供直接的 vLLM OpenAI 兼容服务示例。
- 失败原因：尚无 Radeon Cloud 实例指纹，不能仅凭文档断言“当前实例 + 当前镜像 + Qwen3-VL-8B”组合已通过。
- 下一步：先运行 `scripts/environment_fingerprint.py`，再启动四小时兼容性门。

## 2026-07-28 / STEP-04 / 本地仓库骨架

- 状态：完成
- 操作：创建本地 Git 工作树、README、环境指纹、本地调用强制器、vLLM 启动、冒烟验证、GPU 记录与基线脚本。
- 可核验输出：
  - 已初始化本地 Git 仓库，分支为 `main`。
  - `python3 -m unittest discover -s tests -v`：9 项测试全部通过。
  - Python 文件通过 `py_compile`。
  - 所有 Shell 脚本通过 `bash -n`。
  - 以 `VLLM_HOST=0.0.0.0` 运行启动脚本被预期拒绝，退出码为 2。
- 失败原因：无。
- 下一步：用户接管 Radeon Cloud 登录/实例确认；获得实例 Terminal 后执行环境指纹。

## 2026-07-28 / STEP-05 / 初始 Git 提交

- 状态：阻塞（文件已暂存，未提交）
- 命令：`git commit -m "Bootstrap AMD local inference environment"`
- 可核验输出：Git 仓库位于 `main` 分支，全部新增文件已进入暂存区。
- 失败原因：本机 Git 未配置作者姓名和邮箱，Git 拒绝创建提交。
- 下一步：由用户提供希望用于本仓库的 Git 作者姓名和邮箱；只配置仓库级身份后再提交，不改全局 Git 配置。

## 2026-07-28 / STEP-06 / Radeon Cloud 资源与模板选项

- 状态：模板待用户确认提交
- 当前资源：
  - Credits Available：10；
  - 计费提示：1 credit / GPU / hour；
  - Active Instance：无；
  - My Templates：无；
  - Credit redemption：平台维护中，暂不可兑换。
- 推荐模板元数据：
  - Title：`Accident Rights Agent - Radeon ROCm`
  - Description：`Private multimodal agent for traffic-accident evidence reconstruction, liability analysis, and rights workflow on AMD Radeon GPU.`
  - Category：`AI Agent`
  - Tags：`ROCm, Radeon, vLLM, Qwen3-VL, multimodal, insurance`
- Container Image：保留当前选择 `ROCm vLLM-dev (Navi) (vllm-dev:rocm7.2.1_navi_ubuntu22.04_py3.10_pytorch_2.9_vllm_0.16.0)`。
- Deploy Type：保留当前选择 `Notebook (Jupyter / OpenCode)`。
- 兼容性依据：
  - `Navi` 是 Radeon 路线；
  - 镜像预装 ROCm 7.2.1、PyTorch 2.9、vLLM 0.16.0，避免现场重新组合二进制依赖；
  - vLLM `v0.16.0` 源码已包含 `Qwen3VLForConditionalGeneration`；
  - Notebook 模式允许 vLLM 仅监听 `127.0.0.1:8000`。
- 其他字段：
  - GitHub Repo URL、Notebook Path、Cover URL 暂留空；
  - Branch 保留 `main`；
  - 建议启用 SSH Access，但须先保存公钥；
  - 本机已有公钥文件 `/Users/jimcheng/.ssh/cofounder_spark_ed25519.pub`，未读取或输出私钥；
  - 表单下方 Storage 必须选择 `Persistent (PVC)`。
- 失败原因：自动化浏览器能确认已登录页面，但读取表单 DOM 持续超时；本次依据用户截图和官方/源码资料核对，未执行提交。
- 下一步：用户保存 SSH 公钥、启用 SSH、确认 `Persistent (PVC)` 后提交模板；Launch 前再次确认信用点消耗。

## 2026-07-28 / STEP-07 / 新版工作区与模型目录字段

- 状态：配置已确定，等待用户提交模板
- UI 变化：当前模板表单未显示官方指南中的 `Storage` 字段，改为
  `Legacy Workspace Mode`，提供：
  - `SSD scratch only (legacy)`
  - `SSD + legacy replication`
- 决策：
  - Legacy Workspace Mode：选择 `SSD + legacy replication`；
  - Model Directory：选择 `None`。
- 原因：
  - scratch-only 语义为临时 SSD，不满足代码、模型和实验记录跨实例保留目标；
  - replication 是当前两个选项中唯一包含复制/持久化语义的选项；
  - ComfyUI、Openclaw、Devzone 均为其他应用的预设模型目录，不属于本项目；
  - Qwen 模型将下载到项目控制的持久目录，并记录确切路径与哈希。
- 风险与验证：
  - 官方 README 仍描述 `Persistent (PVC)`，与当前 UI 命名不一致；
  - 在下载完整模型前，先写入小型 marker 文件，重建实例后验证 marker 是否仍存在；
  - 若 marker 不存在，立即停止大文件下载并联系平台管理员确认持久化语义。
- 下一步：用户选择上述两项并提交模板；Launch 前确认 1 GPU / 1 credit per hour。

## 2026-07-28 / STEP-08 / 模板创建与 Launch 前检查

- 状态：模板已创建，实例尚未启动
- 可核验结果：
  - 模板标题：`Accident Rights Agent - Radeon ROCm`；
  - 镜像来源显示为平台 Image；
  - Visibility：`Profile only`；
  - Actions 已出现 `Launch`；
  - Active Instance 仍为无；
  - Credits Available：10；
  - SSH Public Key 输入框在用户截图中仍为空。
- 自动化动作：尝试将现有
  `/Users/jimcheng/.ssh/cofounder_spark_ed25519.pub` 填入已登录页面。
- 失败原因：Radeon Cloud 页面控制再次超时，无法确认填写动作是否生效；为避免重复内容或误点计费 Launch，未继续点击。
- 下一步：
  1. 用户确认 SSH Public Key 框是否已有内容；
  2. 若为空，粘贴 `.pub` 内容并点击 `Save Key`；
  3. 点击模板 `Launch`；
  4. 工作区达到 100% 后提供 SSH 命令或打开 Notebook Terminal。

## 2026-07-28 / STEP-09 / 首次 SSH 连接

- 状态：阻塞，等待实例内启动 `sshd`
- 用户提供入口：`root@36.150.116.206:31264`
- 第一次命令：使用现有 Ed25519 私钥、BatchMode、20 秒超时和项目级
  known_hosts 文件执行远程 `pwd`。
- 第一次输出：`ssh: connect to host 36.150.116.206 port 31264: Connection refused`
- 重试：等待 5 秒后以相同参数重试。
- 重试输出：仍为 `Connection refused`。
- 失败原因：
  - 网络端口明确拒绝连接，不是公钥认证错误；
  - 结合官方 Radeon Cloud 指南，当前 vLLM-dev 镜像可能未预装或未启动
    OpenSSH Server。
- 下一步：用户从 `Open Notebook` 进入 Jupyter Terminal，安装/启动
  `openssh-server` 和 `/usr/sbin/sshd`；随后再次执行相同 SSH 连接。

## 2026-07-28 / STEP-10 / 打开 Jupyter Terminal

- 状态：Terminal 已打开，等待人工粘贴启动命令
- 可核验结果：
  - JupyterLab 工作区包含 `legacy-workspace`、`lost+found`、`persistent`；
  - Terminal 以 `root` 用户打开；
  - 当前工作目录提示符显示为 `/workspace`；
  - 容器出现非阻塞提示：`groups: cannot find name for group ID 109`。
- 自动化动作：
  - 成功点击 Launcher 中的 Terminal；
  - 尝试输入只读命令 `which sshd`；
  - 尝试改用浏览器剪贴板粘贴。
- 失败原因：JupyterLab 的终端画布在自动输入和剪贴板调用时持续超时，命令未出现在终端；为避免重复或错误命令，停止自动重试。
- 下一步：用户在已打开的 Terminal 手动粘贴安装/启动 `sshd` 的三行命令；完成后 Codex 从本地再次连接 SSH。

## 2026-07-28 / STEP-11 / SSH、PVC 与实例环境指纹

- 状态：完成
- 入口：`root@36.150.116.206:31264`，使用用户已配置的 Ed25519 公钥认证。
- 执行：
  - 通过 SSH 进入实例；
  - 检查 `/workspace`、`/persistent` 与 `legacy-workspace` 的挂载；
  - 将项目同步至 `/persistent/accident-rights-agent`；
  - 在 `/persistent` 创建持久性 marker；
  - 使用 `/opt/venv/bin/python scripts/environment_fingerprint.py` 记录真实运行环境。
- 可核验输出：
  - `/persistent` 为 100 GB NFS/PVC；
  - GPU 为 Navi31 / `gfx1100`，48 GB GDDR6；
  - ROCm 7.2.1；
  - Python 3.10.12；
  - PyTorch `2.9.1+gitff65f5b`，HIP `7.2.53211-e1a6bc5663`；
  - vLLM `0.16.1.dev0+g89a77b108.d20260318`；
  - PyTorch GPU 可用，设备数为 1。
- 失败原因：第一次用系统 `/usr/bin/python3` 记录时无法导入 torch/vLLM；确认预装环境实际位于 `/opt/venv` 后重跑成功。初始错误指纹被保留。
- 下一步：启动四小时模型兼容性门并下载首选模型。

## 2026-07-28 / STEP-12 / Qwen3-VL 本地模型下载

- 状态：完成
- 兼容性门：
  - 开始：`2026-07-28T03:22:50Z`；
  - 截止：`2026-07-28T07:22:50Z`；
  - 首选：`Qwen/Qwen3-VL-8B-Instruct`；
  - 降级：`Qwen/Qwen2.5-VL-7B-Instruct`。
- 下载位置：`/persistent/models/Qwen3-VL-8B-Instruct`
- 执行：
  - Hugging Face 连接连续失败后停止重试；
  - 在 `/persistent/tools/modelscope-venv` 创建隔离下载环境；
  - 通过 ModelScope SDK 下载 17 个文件。
- 可核验输出：
  - 总容量 17 GB；
  - 四个 safetensors 分片全部存在；
  - `model.safetensors.index.json` 映射到恰好四个分片；
  - `config.json` 存在，索引无缺失文件。
- 失败原因：实例到 Hugging Face 的网络路由返回 `Network is unreachable`；ModelScope 可访问。未修改 `/opt/venv`。
- 下一步：以 BF16/auto、16K 上下文启动 Qwen3-VL。

## 2026-07-28 / STEP-13 / Qwen3-VL 第一次启动

- 状态：失败，原因已记录
- 命令参数：
  - 绑定 `127.0.0.1:8000`；
  - `--max-model-len 16384`；
  - `--gpu-memory-utilization 0.90`；
  - 最多 8 张图片；
  - Prefix Cache 基线关闭意图。
- 输出：进程在初始化视觉旋转位置编码时退出。
- 根因：
  `ModuleNotFoundError: No module named 'flash_attn_2_cuda'`。
- 判断：镜像中的 FlashAttention 默认走了 CUDA 导入；不是模型损坏，也不是 OOM。
- 下一步：核对镜像与 vLLM 的 RDNA 后端开关，不卸载包、不改预装环境。

## 2026-07-28 / STEP-14 / RDNA 修复与第二次启动

- 状态：完成
- 修复：
  - 验证镜像内 `flash_attn 2.8.3` 在
    `FLASH_ATTENTION_TRITON_AMD_ENABLE=TRUE` 时可导入所需 rotary 算子；
  - 将该开关固化进 `scripts/serve_vllm.sh`；
  - 模型与 vLLM executable 均限制为批准的固定本地路径。
- 可核验输出：
  - 日志显示 `Using Flash Attention (Triton backend) for ViT model on RDNA`；
  - 四个分片加载完成；
  - 模型权重占用 16.73 GiB；
  - 首次 `torch.compile` 105.53 秒；
  - `/v1/models` 返回 `Qwen/Qwen3-VL-8B-Instruct`；
  - 最大上下文 16,384。
- 失败原因：无。
- 下一步：执行文本、单图和 8 帧多模态验收。

## 2026-07-28 / STEP-15 / 冒烟测试与 AMD GPU 采样

- 状态：完成
- 测试结果：
  - `/v1/models`：通过；
  - 文本严格 JSON：通过，0.99 秒；
  - 单图严格 JSON：通过，6.06 秒；
  - 8 帧严格 JSON：通过，12.13 秒，返回恰好 8 个帧条目；
  - 四小时兼容性门：标记为 `passed`，不切换 Qwen2.5-VL。
- 90 秒 AMD SMI 采样：
  - 样本数：90；
  - GPU 利用率峰值：100%；
  - 显存峰值：43,820 MB；
  - 功耗峰值：190 W；
  - Edge / Hotspot 峰值：38°C / 47°C。
- 限制：合成图只验证本地多模态链路，不代表事故责任分析质量。
- 下一步：显式关闭 Prefix Cache，重启后建立公平基线。

## 2026-07-28 / STEP-16 / 本地安全与公平基线配置

- 状态：完成
- 修正：
  - 发现 vLLM 0.16 在未传参数时默认启用 Prefix Cache；
  - 启动脚本在 `ENABLE_PREFIX_CACHING=0` 时明确传入
    `--no-enable-prefix-caching`；
  - 无 `ss` 的镜像通过 `/proc/net/tcp` 检查监听地址。
- 可核验输出：
  - vLLM 日志：`enable_prefix_caching=False`；
  - 监听检查：端口 8000 仅出现 IPv4 loopback `0100007F`；
  - 运行时代码扫描未发现公共 Qwen、DeepSeek、Hugging Face 或 AMD 公共模型 API 地址；
  - 服务仍只使用 `http://127.0.0.1:8000/v1`。
- 失败原因：无。
- 下一步：运行 20 请求正式基线并保存原始 GPU 记录。

## 2026-07-28 / STEP-17 / 正式文本推理基线

- 状态：完成
- 固定配置：
  - 同一 Navi31 GPU、同一 Qwen3-VL-8B、BF16；
  - Prefix Cache 关闭；
  - 请求 20，并发 1，最大输出 192 token，temperature 0；
  - 一次预热，流式响应。
- 结果：
  - 成功：20/20，成功率 100%；
  - 总墙钟时间：57.11 秒；
  - TTFT：均值 85.9 ms，P50 87.4 ms，P95 87.9 ms；
  - 端到端：均值 2.86 秒，P50 2.82 秒，P95 2.97 秒；
  - 解码：平均 27.46 token/s；
  - 请求吞吐：0.350 requests/s。
- 90 秒 GPU 结果：
  - 平均 / 峰值利用率：59.06% / 100%；
  - 平均 / 峰值功耗：111.19 W / 175 W；
  - 显存峰值：44,246 MB；
  - Edge / Hotspot 峰值：47°C / 56°C；
  - OOM：0；请求失败：0。
- 报告：`benchmarks/reports/baseline-20260728T035633Z-c1.json`
- 原始采样：`artifacts/amd-smi-baseline-20260728T035630Z.log`
- 下一步：保留此配置为 AMD 优化对照组；后续只在相同请求集上比较记忆压缩、Prefix Cache 和批处理参数。

## 2026-07-28 / STEP-18 / 项目产物回收与本地验证

- 状态：完成（Git 提交仍等待身份配置）
- 已下载：
  - 正确与初始环境指纹；
  - 两次 vLLM 启动日志；
  - models/text/image/frames 冒烟 JSON；
  - 多模态与基线 AMD SMI 原始日志；
  - 正式基线 JSON 报告。
- 本地验证：
  - Python 文件通过编译；
  - Shell 文件通过 `bash -n`；
  - 单元测试覆盖本地 URL 强制器、监听解析器和 GPU 汇总器。
- 失败原因：Git 作者姓名和邮箱仍未配置，因此没有擅自创建提交。
- 下一步：用户提供仓库级 Git 作者姓名和邮箱后创建初始提交；随后进入 Case Intake 与证据还原阶段。

## 2026-07-28 / STEP-19 / 初始 Git 提交

- 状态：完成
- 仓库级作者：`JimchengChina <a13554266799@gmail.com>`。
- 提交：`a8224ad60d1e4f7ca59bf3a45401f2532e6e9299`
- 提交说明：`Bootstrap AMD local inference environment`
- 失败原因：无；只配置当前仓库，不修改全局 Git 身份。
- 下一步：实现 Case Intake、Evidence Graph 与证据还原。

## 2026-07-28 / STEP-20 / 证据解析依赖核对

- 状态：完成
- Radeon Cloud 预装：
  - OpenCV `4.13.0`、Pillow `11.0.0`、NumPy `2.1.2`；
  - FastAPI `0.135.1`、Uvicorn `0.42.0`；
  - 无 FFmpeg/FFprobe/Tesseract、无 PyMuPDF/pypdf。
- 决策：
  - 视频使用预装 OpenCV，不引入系统级 FFmpeg；
  - PDF 使用 PyMuPDF，安装到 `/persistent/python-packages`；
  - 通过 `scripts/evidence_python.sh` 注入持久化包目录。
- 第一次安装失败：
  - 默认 PyPI 已取得 25.7 MB wheel 元数据，但下载四分钟无进展；
  - 目标目录保持 0，磁盘仍有 84 GB 可用，不是空间问题；
  - 中止无进展进程，未改动 ROCm/PyTorch/vLLM。
- 第二次安装：
  - 改用实例启动脚本同款清华 PyPI 镜像；
  - 8 秒完成，PyMuPDF `1.28.0`；
  - 版本记录在 `config/radeon-validated-versions.txt`。
- 下一步：执行图片、原生 PDF、扫描 PDF 与短视频链路验收。

## 2026-07-28 / STEP-21 / Case Intake 与 Evidence Graph

- 状态：完成
- 已实现：
  - 安全案件 ID、案件目录隔离、文件签名、SHA256、原子复制、哈希去重；
  - 来源角色、缺件清单和接收状态；
  - SQLite WAL、外键、来源/节点/事实/时间线/冲突/运行/审计表；
  - 图片元数据、PDF 页级文本/扫描页渲染、OpenCV 视频关键帧；
  - 仅访问本地 vLLM 的严格 JSON 事实抽取；
  - 未知 Evidence Node 引用直接拒绝；
  - 模型事实均为 `unverified`，置信度上限 0.9；
  - CLI 与仅回环监听的 FastAPI。
- 失败原因：无。
- 下一步：本地和 Radeon Cloud 两侧回归。

## 2026-07-28 / STEP-22 / 自动测试

- 状态：完成
- 本地：
  - Python 3.14 标准库环境，无 FastAPI/OpenCV/Pillow/PyMuPDF；
  - 26 项测试被发现，25 项通过，API 测试因可选依赖缺失而预期跳过。
- Radeon Cloud：
  - Python 3.10 预装完整运行依赖；
  - 26 项测试通过（包含真实 FastAPI create/upload/read/update-role）；
  - API 应用成功装载。
- 覆盖：
  - 路径穿越、符号/文件签名、哈希去重；
  - SQLite 外键与孤立事实拒绝；
  - 模型伪造节点引用拒绝、置信度上限；
  - 冲突检测、时间线、关键帧选择；
  - 无网络假模型端到端重建；
  - API 案件创建、原始文件上传和读取。
- 失败原因：无。
- 下一步：真实本地模型端到端验收。

## 2026-07-28 / STEP-23 / 真实本地模型证据还原

- 状态：完成
- 第一次图像验收编排失败：
  - 案件创建与文件入库成功；
  - shell 后台分组使后续重建丢失项目工作目录；
  - 报错 `scripts/evidence_python.sh: No such file or directory`；
  - 数据未损坏，改用显式 `cd; monitor &; reconstruct; wait` 后重跑。
- 单图案件：
  - 1 个来源、1 个 Evidence Node、4 条待核验事实；
  - 所有事实引用有效节点；
  - 30 次 AMD SMI：GPU 峰值 100%、VRAM 44,247 MB、功耗 172 W。
- 短视频 + 原生 PDF：
  - 2 个来源均为 `parsed`；
  - 3 个视频帧节点、1 个 PDF 页节点；
  - 18 条待核验事实、4 个时间线事件、0 个运行错误。
- 扫描 PDF：
  - 自动标记 `is_scanned=true`；
  - 页 1 渲染路径、原始来源路径均已保存；
  - 4 条事实全部引用 PDF 页节点，置信度上限 0.9 生效。
- 本地安全复核：
  - 运行时代码扫描未发现公共模型端点；
  - vLLM 端口 8000 仅监听 `127.0.0.1`。
- 限制：
  - 合成材料只证明链路，不代表真实事故识别精度；
  - Qwen3-VL 对简化图形的车辆类别描述存在误差，事实因此不得自动升级为
    `verified`，也不得进入责任结论而跳过人工核验。
- 下一步：整理第二次 Git 提交，随后进入法律 RAG、案件记忆和 Orchestrator。

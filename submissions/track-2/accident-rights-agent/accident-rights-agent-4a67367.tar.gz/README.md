# Accident Rights Agent

比赛版目标：在 AMD Radeon GPU + ROCm 上全流程本地运行的交通事故证据还原、责任分析与权益任务 Agent。

当前仓库已完成五个阶段：

1. AMD 环境核验、本地多模态模型服务、冒烟验证和基线性能；
2. Case Intake、不可变原始文件、PDF/图片/短视频还原、Evidence Graph、
   本地 VLM 事实抽取、时间线、冲突检测与审计记录。
3. 版本化法律 RAG、四层动态案件记忆、LangGraph 状态编排、SQLite
   断点恢复、Verifier 与 Human Approval。
4. 业务层材料完整性、两轮车辆属性、违法/原因力/多假设责任、事故责任/
   民事赔偿/保险支付三对象拆分，以及证据缺口反事实分析。
5. Gradio 案件工作台、可恢复执行进度、证据时间线、责任/权益/审批/
   审计页面、可追溯报告与一键 Golden Case 端到端闭环。

核心模型调用必须指向 `http://127.0.0.1:8000/v1`，禁止使用公共
Qwen、DeepSeek 或其他远程模型 API。

## 2026-07-28 实例验收结果

| 项目 | 已验证结果 |
|---|---|
| GPU | AMD Navi31 / `gfx1100`，48 GB GDDR6 |
| ROCm | 7.2.1 |
| Python / PyTorch | 3.10.12 / `2.9.1+gitff65f5b` |
| vLLM | `0.16.1.dev0+g89a77b108.d20260318` |
| 主模型 | `Qwen/Qwen3-VL-8B-Instruct`，BF16，17 GB 本地权重 |
| 服务 | `127.0.0.1:8000`，内核监听检查通过 |
| 冒烟 | models、文本 JSON、单图 JSON、8 帧时序 JSON 全部通过 |
| 正式基线 | 20/20 成功，并发 1；TTFT P50/P95 87/88 ms |
| 基线解码 | 平均 27.46 token/s；端到端 P50/P95 2.82/2.97 s |
| 基线 GPU | 峰值利用率 100%，显存 44,246 MB，功耗 175 W |

Qwen3-VL 已在四小时兼容性门内通过，因此没有切换到 Qwen2.5-VL。

## 已冻结的部署方式

- 使用 Radeon Cloud 的 Notebook/GPU 实例。若模板仍显示旧版 Storage 字段，
  选择 `Persistent (PVC)`；若当前 UI 显示 `Legacy Workspace Mode`，选择
  `SSD + legacy replication`，并在下载模型前完成重建持久性验证。
- 不使用平台的公共免费模型 API。
- 不使用 `vLLM Model API` 模板作为核心链路，因为官方模板要求模型监听 `0.0.0.0:8000`。
- vLLM 只监听 `127.0.0.1:8000`；Agent 与模型位于同一实例。
- 首选 `Qwen/Qwen3-VL-8B-Instruct`。
- Qwen3-VL 从第一次兼容性尝试起四小时内未通过全部冒烟测试，切换到 `Qwen/Qwen2.5-VL-7B-Instruct`。
- 当前 Navi/RDNA 镜像必须设置 `FLASH_ATTENTION_TRITON_AMD_ENABLE=TRUE`。
- 基线显式使用 `--no-enable-prefix-caching`，后续优化组再开启 Prefix Cache。

## 目录

```text
app/
  graph/workflow.py               LangGraph 状态图与 SQLite 恢复
  graph/verifier.py               引用、证据、一致性和风险语言校验
  agents/intake.py                业务材料完整性与补件路由
  agents/vehicle_nature.py        四分类车辆属性与多假设
  agents/liability.py             违法、原因力、责任分布与反事实
  agents/model_adapter.py         可复现 Fake / 本地 vLLM 解释适配器
  memory/                         四层记忆、事件日志与保护字段
  policy/local_only.py           本地端点强制器
  rag/                            法律语料、Qdrant、混合检索与重排
  schemas/                        Evidence/Legal/Memory/NodeResult 契约
  tools/vehicle_rules.py          版本化、确定性车辆参数比较
artifacts/                        环境、冒烟和性能记录（默认不提交）
benchmarks/
  baseline.py                    流式基线性能脚本
  legal_retrieval.py             12 问检索回归
  orchestrator.py                中断恢复与上下文压缩基准
  reports/
config/
  model.env.example              模型配置样例
docs/
  EXECUTION_LOG.md               每步命令、输出、失败原因和下一步
  MODEL_DECISION.md              模型兼容性决策门
  RADEON_CLOUD_HANDOFF.md        登录、PVC 模板和实例启动接管清单
scripts/
  fetch_laws.py                  官方域名下载、标题和哈希核验
  ingest_laws.py                 SQLite + Qdrant 持久索引构建
  run_orchestrator_demo.sh       人为中断后恢复的一键演示
  environment_fingerprint.py     GPU/ROCm/Python/PyTorch/vLLM 环境指纹
  generate_smoke_frames.py       生成可复现的单图与8帧合成测试图
  model_gate.py                  四小时兼容性计时
  record_gpu_metrics.sh          amd-smi 指标记录
  run_baseline.sh                GPU 记录 + 基线测试
  serve_vllm.sh                  仅监听 127.0.0.1 的 vLLM
  summarize_gpu_metrics.py       将 amd-smi 原始日志汇总为 JSON
  verify_endpoint.py             models/文本/单图/8帧验证
  verify_loopback_listener.py    无 ss 时从 /proc 验证监听地址
  verify_local_only.sh           扫描远程模型调用并检查监听地址
tests/
  rag/ memory/ graph/            新增模块单元与集成验收
  agents/                         AGT-01 至 AGT-08 的 18 项业务测试
```

## Case Intake 与证据还原

### 数据安全边界

- 每宗案件使用独立目录与 SQLite 数据库；
- 原始文件计算 SHA256 后原子复制，重复文件按哈希去重；
- 拒绝路径穿越、符号链接、空文件、伪造扩展名和超限文件；
- 原始文件不做有损压缩；关键帧、PDF 页面图和模型响应均为可再生产物；
- 每条模型事实必须引用已存在的 Evidence Node，否则整次响应失败；
- 模型事实一律为 `unverified`，自报置信度最高 0.9，有不确定项时最高 0.7；
- 本阶段只提取可见/原文事实，不判断责任、赔偿、违法或主观状态。

### 本地命令

Radeon Cloud 上先安装唯一缺失的 PDF 依赖：

```bash
bash scripts/setup_evidence_deps.sh
```

创建案件并接收材料：

```bash
./scripts/evidence_python.sh -m app.cli create-case \
  --case-id CASE-DEMO-001

./scripts/evidence_python.sh -m app.cli ingest CASE-DEMO-001 \
  /path/to/dashcam.mp4 --role dashcam_video

./scripts/evidence_python.sh -m app.cli ingest CASE-DEMO-001 \
  /path/to/accident-determination.pdf --role accident_determination
```

查看缺件、执行还原和导出：

```bash
./scripts/evidence_python.sh -m app.cli intake CASE-DEMO-001
./scripts/evidence_python.sh -m app.cli reconstruct CASE-DEMO-001
./scripts/evidence_python.sh -m app.cli export CASE-DEMO-001 \
  --output artifacts/case-demo-export.json
```

视频解析使用 OpenCV 固定间隔与场景变化候选，过滤严重模糊、过暗/过亮
和近重复帧，最多保留 24 帧。原生 PDF 保留页码与文本；扫描页自动渲染成
本地图像，再送入同实例 Qwen3-VL。单次视觉调用最多八张图。

### 本地 API

```bash
bash scripts/serve_api.sh
```

API 默认只监听 `127.0.0.1:8080`，拒绝 `0.0.0.0`。上传接口使用单文件
原始请求体，文件名和材料角色通过 query 参数传入；核心模型仍只访问
`127.0.0.1:8000`。

### 2026-07-28 真实实例验收

| 验收 | 结果 |
|---|---|
| 本地/远端单元测试 | 本地 26 项发现、25 项通过、API 1 项预期跳过；Radeon Cloud 26 项全通过 |
| 单图案件 | 1 来源、1 节点、4 条带引用的待核验事实 |
| 短视频 + 原生 PDF | 2 来源、4 节点、18 条事实、4 个时间线事件 |
| 扫描 PDF | `is_scanned=true`，页面渲染路径与页码可回溯，4 条事实 |
| 图像重建 GPU 峰值 | 100% GPU、44,247 MB VRAM、172 W |
| 本地红线 | 运行时代码无公共模型端点，端口 8000 仅 loopback |

上述均为合成链路样例，只证明工程链路和证据引用，不代表真实事故识别
准确率。合成视频中模型对简化车辆图形的类别描述并不总是准确，因此事实
保持 `unverified`，后续必须经过冲突检查和人工核验。

## 法律 RAG

### 语料与版本策略

`data/laws/source_manifest.json` 保存统一 schema 和条文级快照。文档和
片段包括 `document_id`、标题、类型、发布机关、地域、版本、公布/生效/
失效日期、状态、题录 URL、正文 URL、抓取时间、条/款/项、来源位置、
`quote_type=verbatim_excerpt`、原文和内容哈希。

- 当前包含 13 份全国人大、政府部门、最高人民法院、公安标准和国家标准
  官方来源材料，共 48 个逐字复核片段；
- `scripts/fetch_laws.py` 只允许访问显式白名单中的官方域名，记录最终
  URL、HTTP 状态、内容哈希和标题核验结果；
- `scripts/audit_legal_quotes.py` 将片段与官方 HTML/PDF 快照逐字比对；
  PDF 版式抽取例外和官方站点证书异常必须以独立指纹记录，摘要不得入库；
- 现行与历史版本单独建记录；导入会拒绝同名现行版本的生效区间重叠；
- 查询同时按 `status`、`effective_date`、`jurisdiction` 和
  `document_type` 过滤；
- 确定性法律结论没有 `LegalCitation` 时 schema 直接拒绝。

官方页面核验：

```bash
.venv/bin/python scripts/fetch_laws.py
.venv/bin/python scripts/audit_legal_quotes.py
```

当前审计结果为 48/48：42 条官方快照自动匹配，3 条官方 PDF 目视复核并
锁定来源 SHA256，3 条 GA 802-2019 由益阳交警官方页搜索索引与公安部
标准题录/官方交叉来源复核。益阳交警正文页本轮直连存在 TLS 证书链异常，
作为来源可达性限制单独记录，不伪装成在线核验成功。

建立本地 SQLite 语料库和 Qdrant 持久索引：

```bash
EMBEDDING_PROVIDER=hash .venv/bin/python scripts/ingest_laws.py
```

上面的 `hash` 只用于无模型依赖的离线回归。Radeon/生产实例配置本地
BGE-M3 后使用：

```bash
EMBEDDING_PROVIDER=bge \
BGE_M3_MODEL_PATH=/persistent/models/bge-m3 \
EMBEDDING_DEVICE=cpu \
.venv/bin/python scripts/ingest_laws.py
```

PyTorch ROCm 环境也可以把设备改为 `cuda`；该名称是 PyTorch 对 ROCm
设备沿用的接口。Embedding 和 reranker 都拒绝远程模型 ID，只接受本地目录。
检索先融合 BM25 与 dense Top-10，再由本地
`bge-reranker-v2-m3` 重排到 Top-4。未配置 reranker 时使用可复现的
启发式插件，并在结果中返回 `degraded_reason`。

运行法律检索与 12 问回归：

```bash
EMBEDDING_PROVIDER=hash RERANKER_PROVIDER=heuristic \
  .venv/bin/python -m app.cli legal-search "事故认定复核期限"
.venv/bin/python benchmarks/legal_retrieval.py \
  --embedding-provider hash --reranker-provider heuristic

BGE_M3_MODEL_PATH=models/bge-m3 \
BGE_RERANKER_MODEL_PATH=models/bge-reranker-v2-m3 \
EMBEDDING_DEVICE=cpu RERANKER_DEVICE=cpu \
  .venv/bin/python benchmarks/legal_retrieval.py \
  --embedding-provider bge --reranker-provider bge
```

2026-07-29 修复语料后，48 个片段的轻量回归结果如下；2026-07-28 的
BGE 行是修复前 50 片段的历史引擎验证，不作为当前语料验收结果：

| 配置 | Recall@4 | MRR | 引用完整率 | 冷启动整轮 |
|---|---:|---:|---:|---:|
| hash + heuristic（当前 48 片段） | 1.0000 | 0.8333 | 1.0000 | 未计时 |
| BGE-M3 + heuristic（历史 50 片段） | 1.0000 | 0.8333 | 1.0000 | 11.87 s |
| BGE-M3 + bge-reranker-v2-m3（历史 50 片段） | 1.0000 | 0.8611 | 1.0000 | 74.81 s |

修复前 BGE-M3 对 50 个片段的首次 CPU 索引构建耗时 32.17 秒，向量维度
1024；当前 48 片段必须在 Radeon/ROCm 环境重新记录 BGE 指标。历史明细保存在
`benchmarks/reports/legal-retrieval-bge-cpu.json`
和 `benchmarks/reports/legal-retrieval-bge-full-cpu.json`。这些是本机 CPU
功能与质量验收数据，不应替代 Radeon ROCm 上的吞吐和显存数据。对应
Python 依赖与模型文件 SHA256 记录在
`config/mac-bge-validated-versions.txt`。

## 动态案件记忆

四层记忆共享现有每案 SQLite，不改变 Evidence Graph：

1. `Evidence Memory`：原始文件和 Evidence Node 只读，不做有损压缩；
2. `Fact Memory`：事实状态投影与追加式迁移事件；
3. `Working Memory`：每个节点只保存当前任务相关上下文和 token 指标；
4. `Case Capsule`：严格 JSON Schema、版本递增、禁止覆盖旧版本。

事实状态只允许在 `unverified / confirmed / disputed / rejected` 间按状态机
迁移，每次记录 actor、UTC 时间、理由和事件版本。ProtectedField 会保护
日期、期限、金额、责任比例、车辆标识、当事人角色、Evidence/Fact/Law ID、
法律版本和人工审批状态。上下文选择前后集合不一致时抛出错误并阻断节点。

## Case Orchestrator

```mermaid
flowchart LR
    A["intake_complete"] --> B["evidence_ready"]
    B --> C["legal_retrieval"]
    C --> D["vehicle_nature"]
    D --> E["liability"]
    E --> F["rights_workflow"]
    F --> G["verifier"]
    G --> P["policy_gate"]
    P --> H["human_approval"]
    B -. "missing_evidence" .-> X["分支处理"]
    C -. "legal_conflict" .-> X
    D -. "low_confidence" .-> X
    E -. "node_failed" .-> X
    F -. "missing_delivery_date" .-> X
    F -. "deadline_disputed" .-> X
    P -. "policy_blocked" .-> H
    X --> G
```

每个节点返回统一 `NodeResult`：状态、起止时间、输入哈希、输出、警告、
错误、重试次数和耗时。schema/JSON 错误只修复并重试一次；超时和其他
异常写入明确失败状态。`case_id/thread_id` 是 SQLite 检查点恢复键。
恢复只从下一节点继续，不重复已完成的证据解析。

对现有案件运行、查看状态与恢复：

```bash
.venv/bin/python -m app.cli orchestrate CASE-DEMO-001 \
  --thread-id THREAD-DEMO-001 --interrupt-after evidence_ready
.venv/bin/python -m app.cli workflow-status THREAD-DEMO-001
.venv/bin/python -m app.cli resume THREAD-DEMO-001
```

一键创建纯合成案件、暂停、查看检查点并恢复：

```bash
bash scripts/run_orchestrator_demo.sh
```

API 对应提供：

```text
POST /cases/{case_id}/workflow
GET  /workflows/{thread_id}
POST /workflows/{thread_id}/resume
POST /workflows/{thread_id}/approval
```

Verifier 检查 Evidence ID、法律引用有效期、车辆属性与赔偿路径、责任与
事实相容性、无证据确定性断言和保护字段。人工批准前，权益任务与文书只能
保持 `draft`，不得出现“已提交”或“已发送”。

## Rights Workflow、版本化规则与 Policy Gate

`rights_workflow` 完成六项确定性处理：

1. `DeliveryDateExtractor` 按“人工确认 → 送达回执 → 签收/电子送达 →
   文书落款”的优先级解析日期。落款日期仅标记为弱证据，多个可信送达
   日期冲突时返回 `disputed`，不会自动选择；
2. `DeadlineCalculator` 从 `config/rules/national_rules.json` 读取规则，
   使用带内容哈希的 `config/rules/calendars/cn_2026.json` 计算工作日，
   不在 Prompt 中写死期限；
3. `RightsTaskPlanner` 生成取证、复核、鉴定、保险报案和理赔沟通任务；
4. `EvidenceGapPlanner` 把缺失证据转为合法收集方式、替代证据、降级处理
   和条件化反事实影响；
5. `ReviewApplicationDraftGenerator` 只输出 `draft`，每个事实句关联
   Fact/Evidence ID，每个法律结论关联 `LegalCitation`；
6. `HumanApprovalManager` 将审批绑定到文书版本和输入哈希。文书或关键输入
   变化后，旧审批自动失效并回到 `pending`。

版本化规则通过 `as_of_date + jurisdiction + authority_level` 选择；内容
哈希不匹配、同事项存在多个适用版本、规则失效或地区不匹配时均失败关闭。
车辆技术符合性与法律属性分开处理，禁止“超标 = 自动机动车”。赔偿路由把
事故责任、民事赔偿、交强险、商业险和未覆盖损失分成独立对象；保单限额、
条款、损失、免责或既付金额不全时，保险金额固定为
`insufficient_data`。

最终 Policy Gate 聚合 Evidence、Legal、Consistency、Risk Language 和
ProtectedField 校验。Gate 通过也只表示可以进入人工审查，不表示已经对外
提交。`approved` 前，文书始终为 `draft`，任务不能进入 `submitted`、
`sent` 或 `completed_by_external_authority`。

CLI 示例：

```bash
.venv/bin/python -m app.cli orchestrate CASE-DEMO-001 \
  --thread-id THREAD-DEMO-001
.venv/bin/python -m app.cli workflow-status THREAD-DEMO-001
.venv/bin/python -m app.cli approve THREAD-DEMO-001 \
  --decision approved --approver legal-reviewer \
  --comments "已核对事实、证据链和适用法律版本"
```

完整 schema、规则策略、分支和 API 字段见
`docs/RIGHTS_RULES_VERIFIER_ARCHITECTURE.md`；RGT-01 至 VER-05 的完成状态、
测试和限制见 `docs/rights_rules_verifier_execution_report.md`。

### 本地三 Agent 体验面板

无需 Radeon 实例或远程模型即可体验当前确定性业务逻辑：

```bash
.venv/bin/python -m uvicorn app.api.main:app \
  --host 127.0.0.1 --port 8080
```

浏览器打开 `http://127.0.0.1:8080/experience`。面板内置三个纯合成案件：

- Demo A：材料较完整，可形成受限定的车辆属性判断与责任排序；
- Demo B：只有明显超标参数但缺少登记、鉴定，不能直接定性为机动车；
- Demo C：登记与轨迹材料冲突，车辆属性进入 disputed 并阻断唯一责任结论。

每次点击都会创建新的本地案件，并真实经过 Case Intake、法律 RAG、
Vehicle Nature、Liability、Verifier 和 Human Approval 节点。体验数据不
重新执行 OCR/视频解析，不访问公共 Qwen、DeepSeek 或其他公网模型 API。

## 三类业务 Agent（AGT-01 至 AGT-08）

业务 Agent 不重新解析原始材料。它们共享同一 `CaseState`、Evidence
Graph、Fact Memory、Case Capsule 和 `LegalCitation`，并把结果写回
SQLite 审计日志。

### Case Intake Agent

`assess_business_intake` 在既有证据还原结果上输出严格
`CaseIntakeResult`：

- `uploaded_materials`
- `missing_required_materials`
- `missing_optional_materials`
- `quality_issues`
- `blocking_issues`
- `next_collection_actions`
- `route_hint`

每个缺失项都包含 `reason / required_for / priority /
collection_method / related_agent / blocks_conclusions`。没有 Evidence Node
或 Fact 时进入 `missing_evidence`；仅缺登记、鉴定、信号相位等材料时仍可
继续多假设分析，但相应确定性结论被阻断。

### Vehicle Nature Agent

`VehicleNatureResult.classification` 只允许：

```text
non_motor_vehicle
suspected_motor_vehicle
motor_vehicle
insufficient_evidence
```

`config/vehicle_parameter_rules.json` 版本化比较设计最高车速、整车质量、
电机额定连续输出功率、蓄电池标称电压、脚踏骑行能力、防篡改/解除限速、
车辆尺寸、合格证/CCC、号牌/登记和改装。规则工具只输出
`compliant / non_compliant / unknown / conflicting / not_applicable`，
不输出法律属性。

当登记、鉴定或其他核心材料缺失时，技术参数不符合最多推动结果进入
`suspected_motor_vehicle`；只有可引用的登记/鉴定事实和有效
`LegalCitation` 才允许输出受限定的机动车或非机动车结论。所有结果至少
携带两个 `VehicleNatureHypothesis`。

### Liability Agent

`LiabilityResult` 包含：

```json
{
  "violation_matrix": [],
  "causation_matrix": [],
  "liability_hypotheses": [],
  "responsibility_probabilities": {},
  "accident_responsibility": {},
  "civil_compensation_allocation": {},
  "insurance_payment_estimate": {
    "status": "insufficient_data"
  },
  "compensation_regime": "pending_vehicle_classification",
  "counterfactual_analysis": [],
  "uncertainty": {}
}
```

违法矩阵对双方分别覆盖通行方向、车道、信号/标志、让行、速度、观察、
制动、逆行、横穿、载人、夜间照明和改装。只有 Fact、Evidence 和有效法律
引用同时存在时才使用 `confirmed`。

原因力区分触发性、主要、次要、条件性和无因果关系，不按违法数量分责。
责任概率由透明、可配置的规则分值与 softmax 基线生成，至少保留三个可比较
方案且概率和为 1。关键证据缺失或冲突时，
`unique_conclusion_blocked=true`，不选择唯一方案。

`accident_responsibility`、`civil_compensation_allocation` 和
`insurance_payment_estimate` 是三个独立 schema。缺保单、限额、条款或
损失数据时，保险对象固定返回 `insufficient_data`，不生成金额。

反事实分析固定覆盖路口监控、原始行车记录仪、车辆属性鉴定、信号相位、
碰撞点/刹车痕迹；每一项只描述“若 A/B”的方向性影响，不补造证据。

完整接口、状态流、示例和下一阶段 Rights Workflow 契约见
`docs/BUSINESS_AGENTS_ARCHITECTURE.md`；AGT-01 至 AGT-08 验收见
`docs/business_agents_execution_report.md`。

## Gradio UI 与端到端闭环

比赛版使用单进程 Gradio Blocks，页面只调用 `app/services/`，不复制
Agent、法律规则或状态模型。默认界面面向车主，只保留三个入口：

1. **案件概览**：分析完成后先显示“现在要做什么”，再用普通语言展示
   当前进展、事故概况、首选责任方案、两轮车辆属性、临近期限和关键事实；
2. **权益行动**：按优先级列出后续任务，单独给出车辆属性鉴定行动，并按
   当前程序阶段生成可核对的申请书或沟通稿；
3. **案件材料**：车主和保险公司共同补件，保留原文件、材料分类和提供方
   记录。

保险公司使用默认折叠的“保险公司协作台”，只保留“协助车主、补充材料、
审核文书”三个入口。节点状态、JSON、引用链、checkpoint 和完整审计日志
收在另一个默认折叠的“高级详情与技术诊断”中，普通理赔人员无需理解或
操作。两者与车主界面共享同一 `case_id/thread_id` 和真实 CaseState。

车辆鉴定文书按程序阶段区分：

- 交管部门尚未委托：向事故承办交管部门提交
  `《车辆属性检验、鉴定申请书》`，请求其依法审查并委托；
- 已收到鉴定意见且有异议：原则上在送达之日起三日内向原办案单位提交
  `《重新检验、鉴定申请书》`，请求另行委托鉴定机构；
- 原委托事项遗漏或取得新鉴定材料：提交 `《补充鉴定申请书》`；
  `《补充鉴定书》`是鉴定机构出具的结果，不是车主提交的申请名称；
- 已进入民事诉讼：在法院指定期间内向受理法院提交 `《鉴定申请书》`。

申请事项会明确列出最高设计车速、超过 25km/h 时动力输出、解除限速、
整车质量、电机功率、电池电压、脚踏能力、产品一致性和改装情况，不再只
生成含糊的“请核验车辆参数”。

### 一键启动

首次使用先创建环境并安装锁定依赖：

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
```

无 GPU 的稳定比赛演示：

```bash
DEMO_MODE=mock bash scripts/run_demo.sh
```

连接同机本地 vLLM：

```bash
MODEL_MODE=local_vllm bash scripts/run_demo.sh
```

`local_vllm` 模式会先检查 `127.0.0.1:8000/v1/models`；检查失败即停止，
不会回退到公共 Qwen、DeepSeek 或其他云端模型。默认界面地址为
`http://127.0.0.1:7860`，Golden Case 为 `CASE-GOLDEN-DEMO`，运行日志写入
`artifacts/demo_runtime/`。

三个快速体验案例现在都使用真实文件类型：现场照片为 JPEG，行车记录仪为
H.264 MP4，并生成三个可回溯关键帧；主演示的道路信号材料也为独立 JPEG。
认定书、送达材料、鉴定报告等文档类证据继续使用完整 PDF。所有文件均标注
为合成演示材料，不包含真实当事人信息。`local_vllm` 会把图片与关键帧交给
同机多模态模型，`mock` 则使用相同 Evidence Graph 的确定性演示事实。

主演示的行动卡统一显示 **截止时间：2026 年 8 月 10 日 23:59（UTC+8）**。
主演示将认定书
送达日设为 2026 年 8 月 6 日；按照三工作日规则和 2026 年工作日历，系统
另行计算出的法定复核期限为 8 月 11 日；两类时间在数据层分别保存。

单独执行环境自检与非 UI Golden Case：

```bash
bash scripts/doctor.sh --mode mock --prepare
.venv/bin/python scripts/run_golden_e2e.py --mode mock
```

### Golden Demo 操作与恢复

1. 启动后点击“载入体验案例”，页面会自动恢复 Golden Case；
2. 在“案件概览”查看责任方案、车辆属性、最近期限和关键事实；
3. 点击“分析 / 更新当前事故”，等待真实工作流更新页面；
4. 在“权益行动”查看车辆属性专项行动，选择当前程序阶段并生成申请书；
   对外草稿只陈述可回溯的事故事实、证据缺口和鉴定事项，不写责任方向或
   比例；递交提示采用“当面留存件 + 中国邮政 EMS”双路径固定收件证据；
5. 在“案件材料”展示车主补件入口；未选择文件时只给出提示，不会清空表格
   或显示全页 Error；
6. 展开“保险公司协作台”，理赔员可直接补充同一案件材料，并明确看到当前
   审核的是哪一份复核申请草稿、版本、事实/附件/法律依据数量和缺失事项；
7. 只有评委需要技术证明时，才展开“高级详情与技术诊断”展示证据引用、
   checkpoint、Policy Gate 和完整报告。

模型不可用、schema 错误或解析失败时，已成功节点仍保留在 CaseState 与
SQLite checkpoint；“仅重试失败节点”从失败前 checkpoint 恢复，不会在
输入哈希不变时重新解析视频。固定 3—5 分钟点击路线见
`docs/demo_script.md`，逐项验收与实测见
`docs/ui_e2e_execution_report.md`。

### UI 载入与刷新故障排查

选择或载入 `CASE-GOLDEN-DEMO` 后，事故时间、地点、管辖地区、当事人角色
和送达日期会自动回填。若浏览器仍显示旧版 `Error`，先在启动 UI 的终端按
`Ctrl+C`，再重新运行：

```bash
DEMO_MODE=mock bash scripts/run_demo.sh
```

2026-07-30 已修复反复列出/刷新案件时 SQLite 只结束事务、未显式关闭连接
导致的 `[Errno 24] Too many open files`。证据库、案件记忆、法律语料库和
doctor 自检现均显式关闭连接；合成案件载入也改为单次串行加载，避免同一
按钮触发重复回调。

### 文书和协作入口校准

- 沟通助手不再把模型责任方向、概率、支持度或赔偿比例写入交管申请、
  相对方沟通稿或保险协作稿；
- 申请书按当前程序阶段生成车辆属性检验鉴定、补充鉴定、重新检验鉴定或
  法院司法鉴定申请，并只引用案件事实、原始证据索引和待鉴定事项；
- “当面提交 + EMS”明确标注为收件留痕建议，不冒充法定必经程序；
- 保险协作台的补件入口和车主入口复用同一 CaseService、案件目录和 Evidence
  Graph；未选择文件或文件不合规时保留已有结果并显示可读提示；
- 文书审核页显示具体文书名和版本，审核事实一致性、收件信息、附件完整性
  与请求事项，不再只罗列内部字段或文件名。

## 安装与测试

Radeon Cloud 以 `config/radeon-validated-versions.txt` 为基础环境指纹。
本阶段直接依赖已精确锁定在 `requirements.lock` 和 `pyproject.toml`。

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements.lock
.venv/bin/ruff check app tests
.venv/bin/mypy app
.venv/bin/pytest -q
.venv/bin/python benchmarks/orchestrator.py
```

本地 BGE 模型只在需要构建生产索引时加载。测试不访问云 Embedding API，
也不需要启动 vLLM。

### 已知限制

- BGE-M3 与 bge-reranker-v2-m3 已在 Intel Mac CPU 完成真实本地验收；
  Radeon 目标实例仍需使用其 ROCm Python 环境重建索引，并另行记录 GPU
  时延、显存和并发表现；
- 合成案件规模较小，上下文压缩比例不能代表长案件收益；
- 责任概率仍是透明评分/softmax 工程基线，尚未使用保险或法律专家反馈做
  概率校准，不应解释为司法结果概率；
- 当前 Radeon 实例已销毁，本阶段 Fake/Deterministic adapter、schema、
  规则和工作流已在本地验收；新业务节点的 Qwen3-VL 解释时延、ROCm
  显存与稳定性需在下一次 Active Instance 中补测；
- 车辆规则当前是全国规则包；属地登记管理差异尚未扩展为省市规则包；
- 工作日计算已接入并校验 2026 年国务院节假日与调休表；其他年份没有已
  核验日历时返回 `disputed/needs_legal_review`，不以普通周末规则猜测；
- 系统用截止日 `23:59:59` 作为内部提醒边界，不代表线下受理窗口或电子
  提交系统一定开放至该时点，最终提交可用时点仍需人工确认；
- 2026 年 5 月公开的《道路交通事故处理程序规定》修改征求意见稿未作为
  生效规则使用；规则包仍以当前有效的公安部令第 146 号为准；
- 法律快照仅覆盖比赛主场景相关条款，不代替完整法律数据库或律师审核；
- 车辆技术参数超标不自动等同于机动车属性，最终结论仍需登记、鉴定、
  产品属性和当地管理规则共同支持。

## 在 Radeon Cloud GPU 实例上执行

以下命令均在仓库根目录运行。先确认模板使用 PVC，或在新版 UI 中使用
`SSD + legacy replication`，再打开 Notebook Terminal。

### 1. 记录环境指纹

```bash
/opt/venv/bin/python scripts/environment_fingerprint.py
```

重点检查：

- `amd-smi` 和 `rocminfo` 能识别 GPU；
- PyTorch 的 `torch.version.hip` 非空；
- `torch.cuda.is_available()` 为 `true`（PyTorch ROCm 沿用 `torch.cuda` API）；
- Python 与已安装的 ROCm vLLM wheel 匹配。

### 2. 启动四小时兼容性计时

```bash
/opt/venv/bin/python scripts/model_gate.py start
/opt/venv/bin/python scripts/model_gate.py status
```

### 3. 启动本地 vLLM

模型文件位于持久化卷：

```text
/persistent/models/Qwen3-VL-8B-Instruct
```

当前实例不能直连 Hugging Face，但能访问 ModelScope；模型通过隔离的
`/persistent/tools/modelscope-venv` 下载，未改动预装 `/opt/venv`。

```bash
cp .env.example .env
set -a
source .env
set +a
bash scripts/serve_vllm.sh
```

服务必须显示监听 `127.0.0.1:8000`。另开一个 Terminal 执行：

```bash
bash scripts/verify_local_only.sh
```

### 4. 冒烟验证

先生成可复现的合成测试图，再运行四项验证：

```bash
/opt/venv/bin/python scripts/generate_smoke_frames.py
/opt/venv/bin/python scripts/verify_endpoint.py models
/opt/venv/bin/python scripts/verify_endpoint.py text
/opt/venv/bin/python scripts/verify_endpoint.py image \
  --image-path data/smoke/single/synthetic_intersection.png
/opt/venv/bin/python scripts/verify_endpoint.py frames \
  --frames-dir data/smoke/frames
```

这些合成图片只验证多模态链路，不是事故责任评测样本。

全部通过后：

```bash
python3 scripts/model_gate.py record --result pass --reason "models/text/image/frames all passed"
```

失败时记录真实原因：

```bash
python3 scripts/model_gate.py record --result fail --reason "<错误摘要>"
python3 scripts/model_gate.py status
```

如果状态要求降级：

```bash
export MODEL_ID=/persistent/models/Qwen2.5-VL-7B-Instruct
export SERVED_MODEL_NAME=Qwen/Qwen2.5-VL-7B-Instruct
bash scripts/serve_vllm.sh
```

### 5. 记录 GPU 与基线性能

```bash
bash scripts/run_baseline.sh
```

默认执行一次预热、20 个正式请求、并发 1，并记录：

- TTFT P50/P95；
- 端到端延迟 P50/P95；
- 输出 token/s（服务返回 usage 时）；
- 成功率；
- 推理期间 `amd-smi` 输出。

可覆盖参数：

```bash
BENCH_REQUESTS=20 BENCH_CONCURRENCY=2 GPU_RECORD_SECONDS=180 \
  bash scripts/run_baseline.sh
```

紧凑基线报告保存在 `benchmarks/reports/`。环境指纹、vLLM 原始日志、
冒烟结果和 AMD SMI 原始采样保存在 `artifacts/`；这些运行产物默认被
`.gitignore` 排除，提交前只选择需要公开的脱敏结果。

## 本地安全红线

`app/policy/local_only.py` 会拒绝：

- 非 `http` 协议；
- 非 `127.0.0.1`、`localhost` 或 `::1` 主机；
- 非 `8000` 端口；
- URL 用户名、密码、查询参数或片段；
- `/v1` 之外的路径。

最终 Demo 配置中不得出现公共模型 Base URL 或云端模型 API Key。

## 官方依据

- [AMD Radeon Cloud User Guide](https://github.com/AMD-DEV-CONTEST/Radeon-hackathon-2026-07/blob/main/Radeon-Cloud-User%20Guide/README.md)
- [vLLM AMD ROCm 安装说明](https://docs.vllm.ai/en/stable/getting_started/installation/gpu/)
- [vLLM 支持模型列表](https://docs.vllm.ai/en/latest/models/supported_models/)
- [vLLM Qwen3-VL 使用指南](https://docs.vllm.ai/projects/recipes/en/stable/Qwen/Qwen3-VL.html)
- [Qwen3-VL-8B-Instruct](https://huggingface.co/Qwen/Qwen3-VL-8B-Instruct)
- [Qwen2.5-VL-7B-Instruct](https://huggingface.co/Qwen/Qwen2.5-VL-7B-Instruct)

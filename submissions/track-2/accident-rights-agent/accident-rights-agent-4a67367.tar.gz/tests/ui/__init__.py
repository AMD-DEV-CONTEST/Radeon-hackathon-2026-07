"""UI regression tests."""

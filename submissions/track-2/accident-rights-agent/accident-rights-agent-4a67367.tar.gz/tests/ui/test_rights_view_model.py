from app.ui.view_models import rights_view


def test_due_deadlines_and_high_priority_tasks_are_first(golden_ui_runtime):
    view = rights_view(golden_ui_runtime.state)
    assert view["deadlines"]
    assert view["tasks"]
    ranks = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    task_ranks = [ranks[item["priority"]] for item in view["tasks"]]
    assert task_ranks == sorted(task_ranks)
    assert view["review_application_draft"]["status"] == "draft"
    assert "blocking_fields" in view["review_application_draft"]

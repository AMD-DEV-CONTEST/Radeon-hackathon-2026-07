from app.ui.view_models import liability_view


def test_vehicle_liability_and_compensation_are_consistent(golden_ui_runtime):
    view = liability_view(golden_ui_runtime.state)
    assert view["vehicle_nature"]["classification"] in {
        "non_motor_vehicle",
        "suspected_motor_vehicle",
        "motor_vehicle",
        "insufficient_evidence",
    }
    assert view["responsibility_probabilities"]
    assert (
        abs(sum(view["responsibility_probabilities"].values()) - 1.0)
        < 0.001
    )
    assert view["compensation_regime"] != ""
    assert view["insurance_payment_estimate"]["status"] == "insufficient_data"
    assert view["policy_gate"]["decision"] in {
        "pass",
        "pass_with_warnings",
        "block",
    }

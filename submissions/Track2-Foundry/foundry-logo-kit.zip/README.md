# Foundry — logo kit

The mark is the product: an open square frame (the foundry — the 30B teacher and the
pipeline around it) with a small solid red square cast out through a break in its
corner (the distilled student). It is the same size-squares motif used on the
"student vs teacher" slide, reduced to a signature.

## Files

| File | Use |
|---|---|
| `foundry-logo-horizontal-darkbg.(svg/png)` | Primary lockup on dark surfaces |
| `foundry-logo-horizontal-lightbg.(svg/png)` | Primary lockup on white/light surfaces |
| `foundry-logo-stacked-darkbg.(svg/png)` | Square-ish placements (title slides, covers) |
| `foundry-logo-stacked-lightbg.(svg/png)` | Same, light surfaces |
| `foundry-mark-darkbg.(svg/png)` | Icon only, dark surfaces |
| `foundry-mark-lightbg.(svg/png)` | Icon only, light surfaces |
| `foundry-mark-mono-white/black.(svg/png)` | One-color contexts (print, etching, favicons) |
| `foundry-avatar-1024.png` | Ready-made avatar/app tile (dark, rounded) |

All backgrounds are transparent except the avatar tile. SVGs are the source of
truth; PNGs are exports.

## Color

| Token | Hex |
|---|---|
| Foundry Red (the casting) | `#ED1C24` |
| Ink (light-surface text/frame) | `#101214` |
| Dark surface | `#0E0F11` |

## Type

Wordmark set in **Outfit Bold**, +6% tracking, converted to outlines — the SVGs
render identically everywhere with no font installed. Outfit is licensed under the
SIL Open Font License, so the wordmark is safe for any use, commercial included.

## Usage rules

- Clear space around the logo: at least the width of the red casting square.
- Minimum sizes: mark 16 px, horizontal lockup 24 px tall.
- The casting square stays red in the two-color versions; use the mono variants
  when only one color is available. Do not add effects, outlines, or gradients.
